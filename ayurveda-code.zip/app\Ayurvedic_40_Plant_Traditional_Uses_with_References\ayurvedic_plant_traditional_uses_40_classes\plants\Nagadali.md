# Nagadali — Nagadali / Rue

**Scientific name:** Ruta graveolens
**Taxonomy confidence:** high
**Taxonomy note:** Regional medicinal-plant sources commonly map Nagadali to Ruta graveolens.

## Traditional uses reported in the literature
- Cold-related fever
- Toothache and headache
- Bruises and sprains
- Irregular menstruation
- Infantile eczema in traditional reports

## Traditional treatment context
Historical use includes topical and internal preparations; this package intentionally gives no instructions.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
HIGH-RISK: Ruta graveolens has documented phototoxicity and pregnancy toxicity/abortifacient risk. It should not be used in pregnancy or as a home treatment.

## References
1. Luo et al. Drug Design, Development and Therapy. 2024. *Traditional Uses, Phytochemistry, Pharmacology and Toxicology of Ruta graveolens L.: A Critical Review and Future Perspectives*. DOI: https://doi.org/10.2147/DDDT.S494417 Online: https://pubmed.ncbi.nlm.nih.gov/39758226/
2. Review indexed in PubMed (PMID 33164294). *Is it safe to consume traditional medicinal plants during pregnancy?*. Online: https://pubmed.ncbi.nlm.nih.gov/33164294/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
