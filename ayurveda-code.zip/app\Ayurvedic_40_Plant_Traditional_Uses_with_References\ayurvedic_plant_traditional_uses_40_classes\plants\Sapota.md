# Sapota — Sapota / Sapodilla

**Scientific name:** Manilkara zapota
**Taxonomy confidence:** high
**Taxonomy note:** Sapota/sapodilla corresponds to Manilkara zapota.

## Traditional uses reported in the literature
- Diarrhea and dysentery
- Fever
- Cold and cough
- Indigestion
- Wounds and ulcers
- Traditional bladder/kidney-stone-related use of seeds

## Traditional treatment context
Different structures—fruit, leaves, seeds and bark—have distinct traditional uses.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Clinical trials are limited for many applications. Seeds and extracts should not be used as do-it-yourself stone treatments.

## References
1. Rivas-Gastelum MF, et al. Frontiers in Nutrition. 2023;10:1194283. *Manilkara zapota “chicozapote” as a fruit source of health-beneficial bioactive compounds and its effects on chronic degenerative and infectious diseases, a review*. DOI: https://doi.org/10.3389/fnut.2023.1194283 Online: https://pubmed.ncbi.nlm.nih.gov/37469550/
2. Pharmacological Research - Natural Products. 2024:100062. *A systematic review on traditional use, phytochemistry and pharmacological activities of Manilkara zapota*. DOI: https://doi.org/10.1016/j.prenap.2024.100062 Online: https://doi.org/10.1016/j.prenap.2024.100062

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
