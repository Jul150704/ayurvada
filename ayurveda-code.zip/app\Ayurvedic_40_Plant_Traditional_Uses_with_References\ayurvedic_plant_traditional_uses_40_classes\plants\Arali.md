# Arali — Arali / Sacred fig

**Scientific name:** Ficus religiosa
**Taxonomy confidence:** high
**Taxonomy note:** The medicinal-plant dataset mapping commonly associates Arali/Peepal with Ficus religiosa.

## Traditional uses reported in the literature
- Gastrointestinal complaints
- Respiratory complaints
- Reproductive-system complaints
- Infectious and endocrine-related traditional uses
- Central-nervous-system related traditional uses

## Traditional treatment context
Different plant parts are reported in South Asian ethnomedicine; exact traditional applications depend on part and region.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Evidence is heterogeneous and mostly does not support replacing conventional diagnosis or treatment.

## References
1. Singh D, Singh B, Goel RK. Journal of Ethnopharmacology. 2011;134(3):565-583. *Traditional uses, phytochemistry and pharmacology of Ficus religiosa: a review*. DOI: https://doi.org/10.1016/j.jep.2011.01.046 Online: https://pubmed.ncbi.nlm.nih.gov/21296646/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
