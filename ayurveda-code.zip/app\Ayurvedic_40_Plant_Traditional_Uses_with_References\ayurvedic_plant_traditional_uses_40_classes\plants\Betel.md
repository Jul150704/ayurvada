# Betel — Betel leaf

**Scientific name:** Piper betle
**Taxonomy confidence:** high
**Taxonomy note:** The class label corresponds to Piper betle (betel vine).

## Traditional uses reported in the literature
- Cold, cough and bronchial asthma in traditional use
- Stomach pain and digestive/carminative use
- Rheumatism and pain-related use
- Boils, cuts and wound-related use
- Bad breath, gum swelling and other oral traditional uses

## Traditional treatment context
The cited literature describes leaf use in Ayurveda and folk medicine. Betel leaf is not the same thing as betel quid containing areca nut/tobacco.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Avoid conflating betel leaf with areca-nut chewing. Clinical evidence for many indications remains insufficient.

## References
1. Biswas P, et al. Journal of Cellular and Molecular Medicine. 2022;26:3083-3119. *Betelvine (Piper betle L.): A comprehensive insight into its ethnopharmacology, phytochemistry, and pharmacological, biomedical and therapeutic attributes*. DOI: https://doi.org/10.1111/jcmm.17323 Online: https://pmc.ncbi.nlm.nih.gov/articles/PMC9170825/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
