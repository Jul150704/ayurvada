# Gauva — Guava

**Scientific name:** Psidium guajava
**Taxonomy confidence:** high
**Taxonomy note:** The dataset spelling “Gauva” corresponds to guava, Psidium guajava.

## Traditional uses reported in the literature
- Diarrhea and dysentery
- Traditional hypoglycemic/diabetes-related use
- Cough
- Skin ulcers/wound-related traditional use

## Traditional treatment context
Leaves and fruits are frequently used in folk medicine; the best documented traditional GI use is for diarrhea/dysentery.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Persistent diarrhea, blood in stool, dehydration or diabetes require medical assessment. Concentrated extracts are not equivalent to eating guava fruit.

## References
1. Pérez Gutiérrez RM, Mitchell S, Vargas Solis R. Journal of Ethnopharmacology. 2008;117(1):1-27. *Psidium guajava: a review of its traditional uses, phytochemistry and pharmacology*. DOI: https://doi.org/10.1016/j.jep.2008.01.025 Online: https://pubmed.ncbi.nlm.nih.gov/18353572/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
