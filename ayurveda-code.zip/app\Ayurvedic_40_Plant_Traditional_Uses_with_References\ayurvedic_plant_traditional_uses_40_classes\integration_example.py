import json
from pathlib import Path

DATA = Path(__file__).with_name("plant_information.json")
plant_data = json.loads(DATA.read_text(encoding="utf-8"))
by_class = {p["class_label"]: p for p in plant_data["plants"]}

def get_plant_info(predicted_class: str):
    return by_class.get(predicted_class)

if __name__ == "__main__":
    print(get_plant_info("Neem"))
