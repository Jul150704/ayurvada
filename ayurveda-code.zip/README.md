# Ayurvedic Medicinal Plant AI

A secure starter project for identifying Ayurvedic medicinal plants from images and presenting evidence-based information about traditional uses, treatments and ingredients.

## Stack
- FastAPI backend
- HTML/CSS/JavaScript frontend
- PyTorch/Torchvision image classifier
- SQLite for the starter knowledge base
- Optional research-paper ingestion pipeline

## Important
This is a research/decision-support prototype, not a medical diagnosis or prescribing system. Plant identification should be treated as a prediction with uncertainty. Traditional uses must be presented as traditional claims and separated from clinical evidence.

## Setup
1. Create a virtual environment:
   `python -m venv .venv`
2. Activate it.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Put your image dataset into `data/images/`.
5. Put research papers into `data/research_papers/`.
6. Train:
   `python scripts/train.py`
7. Start:
   `uvicorn app.main:app --reload`
8. Open `http://127.0.0.1:8000`

See `docs/DATASET_GUIDE.md` after adding your dataset.

## Security starter controls
- File-size and extension allowlists
- MIME/content validation
- Randomized temporary upload names
- Upload directory isolation
- No execution of uploaded files
- HTML escaping / safe rendering
- Rate limiting middleware
- Security headers
- CORS restricted to local development
- Environment-based secret configuration
- No hard-coded API keys
- Audit logging
