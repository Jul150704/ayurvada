/* ============================================================
   Ambient garden soundscape

   Synthesised with the Web Audio API rather than shipped as audio
   files: no assets, no CDN, nothing to load. Filtered noise gives
   the rustle of leaves; sparse pentatonic tones suggest a distant
   flute. Muted by default and only ever started by a click, so it
   can never ambush anyone.
   ============================================================ */

const SCALE = [261.63, 293.66, 349.23, 392.0, 440.0, 523.25]; // C major pentatonic

let ctx = null;
let master = null;
let rustle = null;
let fluteTimer = null;
let playing = false;

function buildNoiseBuffer(audio) {
  const frames = audio.sampleRate * 3;
  const buffer = audio.createBuffer(1, frames, audio.sampleRate);
  const data = buffer.getChannelData(0);

  // Cheap pink-ish noise — softer and less hissy than pure white.
  let b0 = 0, b1 = 0, b2 = 0;

  for (let i = 0; i < frames; i += 1) {
    const white = Math.random() * 2 - 1;
    b0 = 0.99765 * b0 + white * 0.099;
    b1 = 0.963 * b1 + white * 0.2965;
    b2 = 0.57 * b2 + white * 1.0526;
    data[i] = (b0 + b1 + b2 + white * 0.1848) * 0.16;
  }

  return buffer;
}

function startRustle() {
  const source = ctx.createBufferSource();
  source.buffer = buildNoiseBuffer(ctx);
  source.loop = true;

  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 780;
  filter.Q.value = 0.6;

  const gain = ctx.createGain();
  gain.gain.value = 0.22;

  // A slow LFO opens and closes the filter, like wind moving through leaves.
  const lfo = ctx.createOscillator();
  lfo.frequency.value = 0.06;

  const lfoDepth = ctx.createGain();
  lfoDepth.gain.value = 340;

  lfo.connect(lfoDepth).connect(filter.frequency);
  source.connect(filter).connect(gain).connect(master);

  source.start();
  lfo.start();

  return { source, lfo };
}

function playFluteNote() {
  const now = ctx.currentTime;
  const freq = SCALE[Math.floor(Math.random() * SCALE.length)];

  const osc = ctx.createOscillator();
  osc.type = "triangle";
  osc.frequency.value = freq;

  // A touch of breath on the attack
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 1500;

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.09, now + 0.6);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.4);

  osc.connect(filter).connect(gain).connect(master);
  osc.start(now);
  osc.stop(now + 3.6);
}

function scheduleFlute() {
  const wait = 6000 + Math.random() * 11000;

  fluteTimer = window.setTimeout(() => {
    if (playing) {
      playFluteNote();
      scheduleFlute();
    }
  }, wait);
}

export async function start() {
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return false;

  if (!ctx) {
    ctx = new Ctor();
    master = ctx.createGain();
    master.gain.value = 0;
    master.connect(ctx.destination);
  }

  if (ctx.state === "suspended") await ctx.resume();

  if (!rustle) rustle = startRustle();

  playing = true;

  // Fade in over four seconds — never an abrupt arrival.
  master.gain.cancelScheduledValues(ctx.currentTime);
  master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
  master.gain.linearRampToValueAtTime(0.06, ctx.currentTime + 4);

  scheduleFlute();
  return true;
}

export function stop() {
  playing = false;
  window.clearTimeout(fluteTimer);

  if (!ctx || !master) return;

  master.gain.cancelScheduledValues(ctx.currentTime);
  master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
  master.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.2);
}

export function initSound() {
  const toggle = document.getElementById("soundToggle");
  if (!toggle) return;

  let on = false;

  toggle.addEventListener("click", async () => {
    on = !on;

    if (on) {
      const ok = await start();
      if (!ok) {
        on = false;
        return;
      }
    } else {
      stop();
    }

    toggle.setAttribute("aria-pressed", String(on));
    toggle.setAttribute(
      "aria-label",
      on ? "Mute the ambient garden sound" : "Play ambient garden sound"
    );

    const icon = toggle.querySelector("use");
    if (icon) icon.setAttribute("href", on ? "#i-sound-on" : "#i-sound-off");
  });
}
