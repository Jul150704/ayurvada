# Curry_Leaf — Curry leaf

**Scientific name:** Murraya koenigii
**Taxonomy confidence:** high
**Taxonomy note:** Curry leaf/sweet neem corresponds to Murraya koenigii.

## Traditional uses reported in the literature
- Piles/hemorrhoids in traditional use
- Inflammation, itching and fresh cuts
- Dysentery and amoebiasis-related traditional use
- Diabetes-related traditional use
- Hepatitis-related traditional use

## Traditional treatment context
Fresh leaves and combinations with foods are reported in Ayurveda/folk practice; this package does not reproduce recipes.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Do not use traditional claims to self-treat diabetes, hepatitis or serious gastrointestinal disease. Evidence is largely preclinical for many outcomes.

## References
1. Jachak SM, et al. Current Pharmaceutical Design. 2024;30(41):3255-3275. *Murraya koenigii (L.) Spreng. as a Natural Intervention for Diabesity: A Review*. DOI: https://doi.org/10.2174/0113816128304471240801183021 Online: https://pubmed.ncbi.nlm.nih.gov/39253925/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
