# Security design

Implemented in the starter:
- Upload extension allowlist
- Upload size limit
- PIL image validation instead of trusting filename/MIME
- Randomized upload identifiers
- No user-controlled filesystem paths
- Security headers
- Restrictive local CORS
- Rate limiting on prediction endpoint
- No secrets committed to source control
- Safe DOM text insertion in frontend
- Logging without storing the uploaded image

Before deployment:
- Run behind HTTPS
- Use a production reverse proxy
- Add authentication/authorization if research data is private
- Store uploads outside the public web root
- Add malware scanning for uploaded files
- Add CSRF protection if cookie-based authentication is introduced
- Encrypt sensitive stored data
- Add database access controls
- Keep dependencies patched
- Add model/version audit trails
- Validate extracted research text before indexing
- Never let uploaded papers/images execute as code
