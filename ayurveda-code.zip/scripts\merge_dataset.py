"""Merge the overlapping classes from 'additional dataset.zip' into data/images.

Only folders that map to an existing class are used. Every added file is named
ext_<n>.jpg so the merge can be undone with a single delete of ext_* files.

Exact-duplicate images (byte hash) are skipped, both against the existing
dataset and within the new one, so the same photo can never land in both the
train and validation split and inflate the score.
"""
from pathlib import Path
import hashlib
import io
import sys
import zipfile

from PIL import Image

ZIP = Path(r"C:\Users\ramda\Downloads\additional dataset.zip")
DEST = Path("data/images")
MAX_SIDE = 800          # only oversized phone photos get resampled
JPEG_QUALITY = 92

# Zip folder -> existing class. Aliases were verified against the
# scientific_name field in data/plant_info/plant_information.json.
MAPPING = {
    # identical names
    "Aloevera": "Aloevera", "Amla": "Amla", "Arali": "Arali", "Bamboo": "Bamboo",
    "Betel": "Betel", "Castor": "Castor", "Ekka": "Ekka", "Ganike": "Ganike",
    "Henna": "Henna", "Hibiscus": "Hibiscus", "Honge": "Honge", "Insulin": "Insulin",
    "Jasmine": "Jasmine", "Lemon": "Lemon", "Mango": "Mango", "Mint": "Mint",
    "Neem": "Neem", "Nooni": "Nooni", "Pepper": "Pepper", "Rose": "Rose",
    "Sapota": "Sapota",
    # spelling / regional-name aliases
    "Amruthaballi": "Amruta_Balli",              # Tinospora cordifolia
    "Bhrami": "Brahmi",                          # Bacopa monnieri
    "Catharanthus": "Nithyapushpa",              # Catharanthus roseus
    "Curry": "Curry_Leaf",                       # Murraya koenigii
    "Doddpathre": "Doddapatre",                  # Plectranthus amboinicus
    "Guava": "Gauva",                            # Psidium guajava
    "Lemongrass": "Lemon_grass",                 # Cymbopogon citratus
    "Malabar_Spinach": "Basale",                 # Basella alba
    "Papaya": "Pappaya",                         # Carica papaya
    "Pomoegranate": "Pomegranate",               # Punica granatum
    "Tulsi": "Tulasi",                           # Ocimum tenuiflorum
    "ashoka": "Ashoka",                          # Saraca asoca
    "Common rue(naagdalli)": "Nagadali",         # Ruta graveolens
}
# Deliberately excluded: Seethaashoka (Polyalthia longifolia, a different
# species from Saraca asoca), Palak(Spinach)/Spinach1 (Spinacia, not Basella),
# and every non-overlapping class.


def main():
    if not ZIP.exists():
        sys.exit(f"Archive not found: {ZIP}")
    if not DEST.exists():
        sys.exit(f"Destination not found: {DEST.resolve()}")

    print("Hashing existing images...")
    seen = set()
    existing_per_class = {}
    for class_dir in DEST.iterdir():
        if not class_dir.is_dir():
            continue
        n = 0
        for img in class_dir.iterdir():
            if img.is_file() and img.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}:
                seen.add(hashlib.sha1(img.read_bytes()).hexdigest())
                n += 1
        existing_per_class[class_dir.name] = n
    print(f"  {len(seen)} unique hashes across {len(existing_per_class)} classes\n")

    added = {k: 0 for k in set(MAPPING.values())}
    dup = resized = corrupt = skipped_class = 0
    counter = 0

    with zipfile.ZipFile(ZIP) as z:
        entries = [i for i in z.infolist() if not i.is_dir()]
        total = len(entries)

        for idx, info in enumerate(entries, 1):
            parts = info.filename.split("/")
            if len(parts) < 3:
                continue

            target = MAPPING.get(parts[1])
            if target is None:
                skipped_class += 1
                continue

            raw = z.read(info)
            digest = hashlib.sha1(raw).hexdigest()
            if digest in seen:
                dup += 1
                continue
            seen.add(digest)

            try:
                im = Image.open(io.BytesIO(raw))
                im.load()
            except Exception:
                corrupt += 1
                continue

            out_dir = DEST / target
            out_dir.mkdir(exist_ok=True)
            counter += 1
            out_path = out_dir / f"ext_{counter:05d}.jpg"

            if max(im.size) > MAX_SIDE:
                im = im.convert("RGB")
                im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
                im.save(out_path, "JPEG", quality=JPEG_QUALITY)
                resized += 1
            elif im.mode != "RGB" or info.filename.lower().endswith((".png", ".webp")):
                im.convert("RGB").save(out_path, "JPEG", quality=JPEG_QUALITY)
            else:
                out_path.write_bytes(raw)

            added[target] += 1

            if idx % 500 == 0:
                print(f"  scanned {idx}/{total} · added {counter}")

    print("\n=== merge complete ===")
    print(f"added            {counter}")
    print(f"exact duplicates {dup}")
    print(f"resized (>{MAX_SIDE}px) {resized}")
    print(f"corrupt skipped  {corrupt}")
    print(f"other classes    {skipped_class}")

    print("\n=== per-class before -> after ===")
    grand_before = grand_after = 0
    for cls in sorted(existing_per_class):
        before = existing_per_class[cls]
        after = before + added.get(cls, 0)
        grand_before += before
        grand_after += after
        flag = "" if added.get(cls, 0) else "   (no new data)"
        print(f"  {cls:16s} {before:5d} -> {after:5d}  (+{added.get(cls,0)}){flag}")
    print(f"\n  {'TOTAL':16s} {grand_before:5d} -> {grand_after:5d}  (+{grand_after-grand_before})")


if __name__ == "__main__":
    main()
