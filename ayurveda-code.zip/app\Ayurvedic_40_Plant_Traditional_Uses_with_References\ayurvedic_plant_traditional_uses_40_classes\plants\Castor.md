# Castor — Castor

**Scientific name:** Ricinus communis
**Taxonomy confidence:** high
**Taxonomy note:** The class label corresponds to Ricinus communis.

## Traditional uses reported in the literature
- Processed castor oil historically used as a laxative for constipation
- Traditional use for pain/inflammation
- Traditional use in some menstrual-related remedies

## Traditional treatment context
Medicinal descriptions must distinguish properly processed castor oil from raw seeds/plant material.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
HIGH-RISK: Castor seeds contain ricin, a potent toxin. Raw seeds and unverified preparations must never be used as home remedies. Processed pharmaceutical castor oil is a different product.

## References
1. Franke H, Scholl R, Aigner A. Naunyn-Schmiedeberg’s Archives of Pharmacology. 2019. *Ricin and Ricinus communis in pharmacology and toxicology—from ancient use to modern perspectives*. Online: https://pubmed.ncbi.nlm.nih.gov/31359089/
2. Worbs S, et al. Toxins. Review indexed in PubMed (PMID 22069699). *Ricinus communis intoxications in human and veterinary medicine—a summary of real cases*. Online: https://pubmed.ncbi.nlm.nih.gov/22069699/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
