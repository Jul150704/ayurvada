# Lemon_grass — Lemongrass

**Scientific name:** Cymbopogon citratus
**Taxonomy confidence:** high
**Taxonomy note:** Lemongrass in medicinal datasets most commonly maps to Cymbopogon citratus.

## Traditional uses reported in the literature
- Cold, cough and sore throat
- Headache and dizziness
- Loss of appetite and abdominal pain
- Diarrhea
- Rheumatism-related traditional use

## Traditional treatment context
Traditionally consumed as aromatic herbal preparations and used externally in some cultures; no recipe or dose is included.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Human clinical evidence is limited for many conditions. Essential oil is concentrated and can irritate skin or interact with medications.

## References
1. Journal of Ethnopharmacology. 2024; review indexed in PubMed (PMID 38608798). *Ethnobotanical uses, phytochemistry and bioactivities of Cymbopogon plants: A review*. DOI: https://doi.org/10.1016/j.jep.2024.118181 Online: https://pubmed.ncbi.nlm.nih.gov/38608798/
2. Pharmacognosy Reviews. Review indexed in PubMed (PMID 22171285). *Scientific basis for the therapeutic use of Cymbopogon citratus, stapf (Lemon grass)*. DOI: https://doi.org/10.4103/2231-4040.79796 Online: https://pubmed.ncbi.nlm.nih.gov/22171285/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
