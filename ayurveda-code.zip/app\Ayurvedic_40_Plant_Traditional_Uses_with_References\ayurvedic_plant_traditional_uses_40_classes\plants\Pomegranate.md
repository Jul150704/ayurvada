# Pomegranate — Pomegranate

**Scientific name:** Punica granatum
**Taxonomy confidence:** high
**Taxonomy note:** The class label corresponds to Punica granatum.

## Traditional uses reported in the literature
- Peptic-ulcer related traditional use
- Oral diseases
- Traditional use for diabetes, hypertension and hyperlipidemia
- Atherosclerosis-related traditional use
- Traditional cancer-related use in several medical systems

## Traditional treatment context
Fruit, rind, flower, bark and other parts have different compositions; this dataset summarizes indications rather than formulations.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Traditional use for cardiometabolic disease or cancer is not proof of clinical efficacy and should not replace standard treatment.

## References
1. Ge S, et al. Journal of Ethnopharmacology. 2021;271:113877. *A unique understanding of traditional medicine of pomegranate, Punica granatum L. and its current research status*. DOI: https://doi.org/10.1016/j.jep.2021.113877 Online: https://pubmed.ncbi.nlm.nih.gov/33515685/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
