# Hibiscus — Hibiscus / China rose

**Scientific name:** Hibiscus rosa-sinensis
**Taxonomy confidence:** high
**Taxonomy note:** The medicinal-plant dataset mapping commonly uses Hibiscus rosa-sinensis for this class.

## Traditional uses reported in the literature
- Traditional women’s/reproductive-health uses
- Fever and inflammation-related use
- Hair and scalp care
- Skin/wound-related traditional use

## Traditional treatment context
Flowers, leaves and other parts are used in different traditional systems; the women’s-health literature documents H. rosa-sinensis among repeatedly reported species.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Reproductive effects are among reported pharmacological areas; pregnancy/fertility contexts require professional advice rather than self-treatment.

## References
1. Amtaghri S, et al. Endocrine, Metabolic & Immune Disorders - Drug Targets. 2024;24(1):86-115. *A Comprehensive Overview of Hibiscus rosa-sinensis L.: Its Ethnobotanical Uses, Phytochemistry, Therapeutic Uses, Pharmacological Activities, and Toxicology*. DOI: https://doi.org/10.2174/1871530323666230522113405 Online: https://pubmed.ncbi.nlm.nih.gov/37218183/
2. de Boer HJ, et al. Journal of Ethnopharmacology. 2014. *Medicinal plants for women’s healthcare in southeast Asia: a meta-analysis of their traditional use, chemical constituents, and pharmacology*. DOI: https://doi.org/10.1016/j.jep.2013.11.030 Online: https://pubmed.ncbi.nlm.nih.gov/24269772/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
