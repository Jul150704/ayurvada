"""Image-classification training for the Ayurvedic plant model.

Dataset format (unchanged):
data/images/
  Ashwagandha/img001.jpg
  Neem/img001.jpg
  ...

Checkpoint format (unchanged — app/predictor.py depends on it):
  {"state_dict": ..., "classes": [...]}  saved to models/plant_model.pt

The train/val/test split is stratified per class and written to
models/split.json on first run, then reused. Keeping the test set fixed is
what makes "accuracy went up" a real claim rather than split luck.

Usage:
  python scripts/train.py                  # train on everything
  python scripts/train.py --original-only  # ignore merged ext_* images (baseline)
  python scripts/train.py --epochs 15
"""
from pathlib import Path
import argparse
import json
import random
import sys

import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from PIL import Image

DATA = Path("data/images")
OUT = Path("models")
SPLIT_FILE = OUT / "split.json"
SEED = 42
IMG_EXT = {".jpg", ".jpeg", ".png", ".webp"}

# Eval must not be augmented — the original script randomly flipped and
# rotated validation images too, which makes the score noise.
train_tfm = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.RandomResizedCrop(224, scale=(0.7, 1.0)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(12),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])

eval_tfm = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])


class PlantDataset(Dataset):
    def __init__(self, items, classes, tfm):
        self.items = items
        self.classes = classes
        self.index = {c: i for i, c in enumerate(classes)}
        self.tfm = tfm

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        path, label = self.items[i]
        image = Image.open(path).convert("RGB")
        return self.tfm(image), self.index[label]


def build_split():
    """Stratified 70/15/15 split, stable across runs."""
    classes = sorted(d.name for d in DATA.iterdir() if d.is_dir())
    rng = random.Random(SEED)
    split = {"train": [], "val": [], "test": []}

    for cls in classes:
        files = sorted(
            str(p.relative_to(DATA)).replace("\\", "/")
            for p in (DATA / cls).iterdir()
            if p.is_file() and p.suffix.lower() in IMG_EXT
        )
        rng.shuffle(files)

        n = len(files)
        n_test = max(1, int(n * 0.15))
        n_val = max(1, int(n * 0.15))

        split["test"] += files[:n_test]
        split["val"] += files[n_test:n_test + n_val]
        split["train"] += files[n_test + n_val:]

    return classes, split


def load_split():
    if SPLIT_FILE.exists():
        payload = json.loads(SPLIT_FILE.read_text())
        return payload["classes"], payload["split"]

    classes, split = build_split()
    OUT.mkdir(exist_ok=True)
    SPLIT_FILE.write_text(json.dumps({"classes": classes, "split": split}, indent=2))
    print(f"Wrote split to {SPLIT_FILE}")
    return classes, split


def to_items(rel_paths):
    return [(DATA / r, r.split("/")[0]) for r in rel_paths]


@torch.inference_mode()
def evaluate(model, loader, device):
    model.eval()
    correct = total = 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        preds = model(x).argmax(1)
        correct += (preds == y).sum().item()
        total += y.numel()
    return 100.0 * correct / max(total, 1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--original-only", action="store_true",
                        help="Train without the merged ext_* images (baseline run)")
    parser.add_argument("--out", default="plant_model.pt")
    # Windows spawns (not forks) DataLoader workers: each re-imports torch,
    # which is slow and can deadlock alongside a CUDA context. In-process
    # loading is both safer and faster at this dataset size.
    parser.add_argument("--workers", type=int,
                        default=0 if sys.platform == "win32" else 4)
    args = parser.parse_args()

    torch.manual_seed(SEED)
    random.seed(SEED)

    classes, split = load_split()
    train_items = to_items(split["train"])
    val_items = to_items(split["val"])
    test_items = to_items(split["test"])

    if args.original_only:
        # Test and val stay identical so the comparison is honest.
        train_items = [it for it in train_items if not it[0].name.startswith("ext_")]

    print(f"classes {len(classes)} · train {len(train_items)} · "
          f"val {len(val_items)} · test {len(test_items)}")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"device: {device}")

    workers = max(0, args.workers)
    extra = {"persistent_workers": True, "prefetch_factor": 4} if workers else {}
    print(f"dataloader workers: {workers}")

    train_loader = DataLoader(PlantDataset(train_items, classes, train_tfm),
                              batch_size=args.batch_size, shuffle=True,
                              num_workers=workers, pin_memory=(device == "cuda"), **extra)
    val_loader = DataLoader(PlantDataset(val_items, classes, eval_tfm),
                            batch_size=args.batch_size, num_workers=workers, **extra)
    test_loader = DataLoader(PlantDataset(test_items, classes, eval_tfm),
                             batch_size=args.batch_size, num_workers=workers, **extra)

    model = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
    model.fc = nn.Linear(model.fc.in_features, len(classes))
    model.to(device)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    loss_fn = nn.CrossEntropyLoss(label_smoothing=0.05)

    best_acc = -1.0
    best_state = None

    for epoch in range(1, args.epochs + 1):
        model.train()
        running = 0.0

        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            opt.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            opt.step()
            running += loss.item() * y.numel()

        sched.step()
        val_acc = evaluate(model, val_loader, device)
        train_loss = running / max(len(train_items), 1)

        marker = ""
        if val_acc > best_acc:
            best_acc = val_acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            marker = "  <- best"

        print(f"epoch {epoch:2d}/{args.epochs}  loss {train_loss:.4f}  "
              f"val {val_acc:.2f}%{marker}")

    if best_state is not None:
        model.load_state_dict(best_state)

    test_acc = evaluate(model, test_loader, device)
    print(f"\nbest val accuracy  {best_acc:.2f}%")
    print(f"TEST accuracy      {test_acc:.2f}%  ({len(test_items)} held-out images)")

    OUT.mkdir(exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "classes": classes}, OUT / args.out)
    (OUT / "classes.json").write_text(json.dumps(classes, indent=2))
    print("Saved model:", OUT / args.out)


if __name__ == "__main__":
    main()
