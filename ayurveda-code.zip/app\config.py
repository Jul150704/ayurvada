from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "Ayurvedic Plant AI"
    max_upload_mb: int = 8
    allowed_origins: str = "http://127.0.0.1:8000,http://localhost:8000"
    rate_limit: str = "30/minute"
    model_path: str = "models/plant_model.pt"

settings = Settings()
