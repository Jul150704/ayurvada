# Honge — Honge / Indian beech

**Scientific name:** Pongamia pinnata (syn. Millettia pinnata) (probable)
**Taxonomy confidence:** probable
**Taxonomy note:** “Honge” commonly refers to Pongamia pinnata in Karnataka, although vernacular-name overlap exists.

## Traditional uses reported in the literature
- Piles/hemorrhoids
- Skin diseases
- Wounds
- Inflammation-related traditional use

## Traditional treatment context
Multiple plant parts and oils are described traditionally; this entry does not give preparation or dosing instructions.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Seeds/oils and concentrated extracts should not be ingested casually. Botanical identity should be confirmed before displaying medicinal information.

## References
1. Al Muqarrabun LMR, et al. Journal of Ethnopharmacology. 2013;150(2):395-420. *Medicinal uses, phytochemistry and pharmacology of Pongamia pinnata (L.) Pierre: a review*. DOI: https://doi.org/10.1016/j.jep.2013.08.041 Online: https://pubmed.ncbi.nlm.nih.gov/24016802/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
