# Tulasi — Tulasi / Holy basil

**Scientific name:** Ocimum tenuiflorum (syn. Ocimum sanctum)
**Taxonomy confidence:** high
**Taxonomy note:** Tulasi/Tulsi corresponds to Ocimum tenuiflorum; Ocimum sanctum is a widely used synonym in older literature.

## Traditional uses reported in the literature
- Bronchitis and bronchial asthma
- Malaria and chronic/catarrhal fever in traditional use
- Diarrhea and dysentery
- Skin diseases
- Arthritis
- Insect bites

## Traditional treatment context
Leaves and other parts are used in Ayurveda and folk medicine, often in compound preparations.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Traditional use does not establish clinical efficacy for malaria, asthma or serious infection. Medication interactions and pregnancy context require professional advice.

## References
1. Prakash P, Gupta N. Indian Journal of Physiology and Pharmacology. 2005;49(2):125-131. *Therapeutic uses of Ocimum sanctum Linn (Tulsi) with a note on eugenol and its pharmacological actions: a short review*. Online: https://pubmed.ncbi.nlm.nih.gov/16170979/
2. Review indexed in PubMed (PMID 39473808). *A Comprehensive Review of the Phytochemical Constituents and Bioactivities of Ocimum tenuiflorum*. Online: https://pubmed.ncbi.nlm.nih.gov/39473808/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
