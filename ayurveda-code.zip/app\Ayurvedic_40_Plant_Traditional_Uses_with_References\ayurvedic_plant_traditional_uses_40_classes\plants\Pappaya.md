# Pappaya — Papaya

**Scientific name:** Carica papaya
**Taxonomy confidence:** high
**Taxonomy note:** The dataset spelling “Pappaya” corresponds to Carica papaya.

## Traditional uses reported in the literature
- Inflammation and pain
- Hypertension
- Diabetes
- Dermatitis
- Asthma
- Stomach problems

## Traditional treatment context
Fruit, leaves, seeds, latex and other parts have distinct traditional uses; no preparation instructions are given.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
The cited review emphasizes that toxicity, efficacy and clinical trials are still needed before therapeutic use. Latex/unripe-papaya preparations require extra caution, especially in pregnancy.

## References
1. Akanda MKM, et al. Inflammopharmacology. 2025;33(6):3051-3084. *Carica papaya in health and disease: a review of its bioactive compounds for treating various disease conditions, including anti-inflammatory and anti-arthritic activities*. DOI: https://doi.org/10.1007/s10787-025-01780-4 Online: https://pubmed.ncbi.nlm.nih.gov/40392387/
2. Review indexed in PubMed (PMID 33164294). *Is it safe to consume traditional medicinal plants during pregnancy?*. Online: https://pubmed.ncbi.nlm.nih.gov/33164294/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
