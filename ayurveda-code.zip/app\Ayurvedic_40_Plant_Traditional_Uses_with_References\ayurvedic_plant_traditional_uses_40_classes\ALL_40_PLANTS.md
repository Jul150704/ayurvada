# Traditional uses and treatment context — all 40 plant classes

Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.

## Important taxonomy note
Several dataset labels are common names rather than species names. Classes marked **ambiguous** or **probable** should not be presented as a definitive species identification until your dataset source is botanically verified.

## Aloevera — Aloe vera
**Scientific name:** Aloe vera  
**Taxonomy confidence:** high  
**Taxonomy note:** The dataset label closely corresponds to Aloe vera.

**Traditional uses reported:**
- Topical use for minor burns and irritated skin
- Traditional wound/skin care
- Aloe latex has historically been used as a laxative for constipation

**Treatment context:** Traditional reports distinguish inner gel/topical use from latex. No dose or self-treatment instructions are provided here.

**Safety:** Oral aloe latex can cause significant adverse effects and is not equivalent to topical aloe gel. Pregnancy and medication interactions require professional review.

**References:**
- Aloe vera: a short review (2008). https://pmc.ncbi.nlm.nih.gov/articles/PMC2763764/ https://doi.org/10.4103/0019-5154.44785
- Is it safe to consume traditional medicinal plants during pregnancy? (2021). https://pubmed.ncbi.nlm.nih.gov/33164294/

## Amla — Amla / Indian gooseberry
**Scientific name:** Phyllanthus emblica (syn. Emblica officinalis)  
**Taxonomy confidence:** high  
**Taxonomy note:** Amla is a well-established common name for Phyllanthus emblica.

**Traditional uses reported:**
- Common cold, cough and fever
- Digestive complaints such as dyspepsia, colic, flatulence and hyperacidity
- Diarrhea/dysentery and other gastrointestinal complaints
- Ayurvedic rejuvenative/nutritional use

**Treatment context:** The fruit is the part most commonly discussed in the cited review; traditional systems use it alone and in compound formulations.

**Safety:** Clinical evidence varies by indication. It can affect glucose or other physiological parameters, so medication users should seek professional advice.

**References:**
- Traditional uses, bioactive composition, pharmacology, and toxicology of Phyllanthus emblica fruits: A comprehensive review (2022). https://pubmed.ncbi.nlm.nih.gov/34480995/ https://doi.org/10.1016/j.jep.2021.114570

## Amruta_Balli — Amruta Balli / Guduchi
**Scientific name:** Tinospora cordifolia  
**Taxonomy confidence:** high  
**Taxonomy note:** Amruta/Amrita Balli and Guduchi commonly refer to Tinospora cordifolia in Indian traditional medicine.

**Traditional uses reported:**
- Fever
- Jaundice and liver-related traditional use
- Diabetes
- Urinary complaints
- Dysentery, skin complaints and helminth-related traditional use

**Treatment context:** Stems and other parts appear in Ayurvedic preparations; this package deliberately omits preparation ratios and doses.

**Safety:** Do not assume “natural” means risk-free. Tinospora products can interact with medicines and should not be used to replace treatment for diabetes, liver disease or infection.

**References:**
- Indian herb Tinospora cordifolia and Tinospora species: Phytochemical and therapeutic application (2024). https://pubmed.ncbi.nlm.nih.gov/38813196/ https://doi.org/10.1016/j.heliyon.2024.e31229

## Arali — Arali / Sacred fig
**Scientific name:** Ficus religiosa  
**Taxonomy confidence:** high  
**Taxonomy note:** The medicinal-plant dataset mapping commonly associates Arali/Peepal with Ficus religiosa.

**Traditional uses reported:**
- Gastrointestinal complaints
- Respiratory complaints
- Reproductive-system complaints
- Infectious and endocrine-related traditional uses
- Central-nervous-system related traditional uses

**Treatment context:** Different plant parts are reported in South Asian ethnomedicine; exact traditional applications depend on part and region.

**Safety:** Evidence is heterogeneous and mostly does not support replacing conventional diagnosis or treatment.

**References:**
- Traditional uses, phytochemistry and pharmacology of Ficus religiosa: a review (2011). https://pubmed.ncbi.nlm.nih.gov/21296646/ https://doi.org/10.1016/j.jep.2011.01.046

## Ashoka — Ashoka
**Scientific name:** Saraca asoca  
**Taxonomy confidence:** high  
**Taxonomy note:** Ashoka is the standard medicinal common name for Saraca asoca in Ayurveda.

**Traditional uses reported:**
- Gynecological complaints
- Menstrual and uterine complaints
- Traditional women’s health formulations

**Treatment context:** Bark and formulations containing Saraca asoca are prominent in traditional Indian medicine; no dosing instructions are included.

**Safety:** Gynecological symptoms such as heavy bleeding can indicate serious conditions and require clinical evaluation. Evidence and product identity can vary.

**References:**
- A comprehensive review on Saraca asoca (Fabaceae) - Historical perspective, traditional uses, biological activities, and conservation (2023). https://pubmed.ncbi.nlm.nih.gov/37390875/ https://doi.org/10.1016/j.jep.2023.116861

## Ashwagandha — Ashwagandha
**Scientific name:** Withania somnifera  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label is unambiguous for Withania somnifera.

**Traditional uses reported:**
- Rasayana/rejuvenative use for strength and nourishment
- Stress and anxiety-related traditional use
- Sleep and nervous-system support
- Male sexual/reproductive vitality in traditional texts

**Treatment context:** Traditionally used in powders/extracts/formulations; this dataset does not provide dosage instructions.

**Safety:** May interact with sedatives, thyroid, glucose, blood-pressure or immune-modulating medicines. Pregnancy use requires professional advice.

**References:**
- Withania somnifera (L.) Dunal - Modern perspectives of an ancient Rasayana from Ayurveda (2021). https://pubmed.ncbi.nlm.nih.gov/32783987/ https://doi.org/10.1016/j.jep.2020.113157

## Avocado — Avocado
**Scientific name:** Persea americana  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label corresponds to Persea americana.

**Traditional uses reported:**
- Menorrhagia/heavy menstrual bleeding in traditional reports
- Hypertension
- Stomach ache
- Bronchitis
- Diarrhea
- Diabetes

**Treatment context:** Traditional use varies by plant part and culture. The cited review documents these ethnomedicinal indications.

**Safety:** These traditional uses do not establish effectiveness for hypertension, diabetes, bleeding or bronchitis; such conditions need appropriate medical care.

**References:**
- The phytochemical and pharmacological profile of Persea americana Mill (2010). https://pubmed.ncbi.nlm.nih.gov/22228945/ https://doi.org/10.4103/0973-7847.65332

## Bamboo — Bamboo
**Scientific name:** Bambusoideae spp.  
**Taxonomy confidence:** ambiguous  
**Taxonomy note:** “Bamboo” is a subfamily-level/common label and does not encode a single species. The cited paper is a broad bamboo-leaf review.

**Traditional uses reported:**
- Cough and cold-related complaints
- Fever
- Rheumatism/inflammatory complaints
- Skin-related traditional uses
- Traditional use for influenza-like symptoms

**Treatment context:** Bamboo leaves are used in several traditional systems; species, plant part and preparation differ substantially.

**Safety:** Species-level identification is required before any medicinal interpretation. Some bamboo species/parts may have distinct safety profiles; pregnancy use should not be assumed safe.

**References:**
- Bamboo leaf: A review of traditional medicinal property, phytochemistry, pharmacology, and purification technology (2023). https://pubmed.ncbi.nlm.nih.gov/36649850/ https://doi.org/10.1016/j.jep.2023.116166
- Is it safe to consume traditional medicinal plants during pregnancy? (2021). https://pubmed.ncbi.nlm.nih.gov/33164294/

## Basale — Basale / Malabar spinach
**Scientific name:** Basella alba  
**Taxonomy confidence:** high  
**Taxonomy note:** Basale commonly refers to Basella alba in South India.

**Traditional uses reported:**
- Traditional demulcent/emollient use
- Digestive and bowel-support/laxative use
- Diuretic/urinary traditional use
- Wound and inflammation-related traditional use

**Treatment context:** Leaves and other parts are used as food and in traditional remedies. No therapeutic dose is supplied.

**Safety:** Food use does not automatically establish medicinal efficacy; concentrated extracts can differ from dietary use.

**References:**
- Comprehensive Ethnomedicinal, Pharmacological and Phytochemical Report on Basella alba L. (Basellaceae) (2023). https://doi.org/10.18311/jnr/2023/34287 https://doi.org/10.18311/jnr/2023/34287

## Betel — Betel leaf
**Scientific name:** Piper betle  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label corresponds to Piper betle (betel vine).

**Traditional uses reported:**
- Cold, cough and bronchial asthma in traditional use
- Stomach pain and digestive/carminative use
- Rheumatism and pain-related use
- Boils, cuts and wound-related use
- Bad breath, gum swelling and other oral traditional uses

**Treatment context:** The cited literature describes leaf use in Ayurveda and folk medicine. Betel leaf is not the same thing as betel quid containing areca nut/tobacco.

**Safety:** Avoid conflating betel leaf with areca-nut chewing. Clinical evidence for many indications remains insufficient.

**References:**
- Betelvine (Piper betle L.): A comprehensive insight into its ethnopharmacology, phytochemistry, and pharmacological, biomedical and therapeutic attributes (2022). https://pmc.ncbi.nlm.nih.gov/articles/PMC9170825/ https://doi.org/10.1111/jcmm.17323

## Betel_Nut — Betel nut / Areca nut
**Scientific name:** Areca catechu  
**Taxonomy confidence:** high  
**Taxonomy note:** Betel nut/areca nut is the seed of Areca catechu.

**Traditional uses reported:**
- Traditional anthelmintic use
- Digestive/stimulant use
- Traditional use for abdominal fluid accumulation and related complaints

**Treatment context:** Historical medicinal use is documented, but this is included for ethnobotanical completeness—not as a recommendation.

**Safety:** HIGH-RISK: Areca nut chewing is carcinogenic to humans and is associated with oral submucous fibrosis and oral cancer risk. It should not be presented or recommended as a treatment.

**References:**
- Areca catechu L. (Arecaceae): a review of its traditional uses, botany, phytochemistry, pharmacology and toxicology (2015). https://pubmed.ncbi.nlm.nih.gov/25681543/ https://doi.org/10.1016/j.jep.2015.02.010
- IARC Monographs: Betel-quid and Areca-nut Chewing and Some Areca-nut-derived Nitrosamines (2004). https://www.ncbi.nlm.nih.gov/books/NBK316567/

## Brahmi — Brahmi
**Scientific name:** Bacopa monnieri  
**Taxonomy confidence:** probable  
**Taxonomy note:** “Brahmi” can be used for more than one herb regionally; in medicinal-plant ML datasets it commonly denotes Bacopa monnieri.

**Traditional uses reported:**
- Memory and learning enhancement in Ayurveda
- Sedative/calming traditional use
- Traditional anti-epileptic use
- Cognitive and nervous-system support

**Treatment context:** Bacopa preparations are widely discussed in Ayurveda and modern supplement research; this dataset does not provide doses.

**Safety:** Can cause adverse effects or interact with medicines. It should not replace treatment for epilepsy, cognitive disorders or psychiatric conditions.

**References:**
- Pharmacological attributes of Bacopa monnieri extract: Current updates and clinical manifestation (2022). https://pubmed.ncbi.nlm.nih.gov/36061899/ https://doi.org/10.3389/fnut.2022.972379

## Castor — Castor
**Scientific name:** Ricinus communis  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label corresponds to Ricinus communis.

**Traditional uses reported:**
- Processed castor oil historically used as a laxative for constipation
- Traditional use for pain/inflammation
- Traditional use in some menstrual-related remedies

**Treatment context:** Medicinal descriptions must distinguish properly processed castor oil from raw seeds/plant material.

**Safety:** HIGH-RISK: Castor seeds contain ricin, a potent toxin. Raw seeds and unverified preparations must never be used as home remedies. Processed pharmaceutical castor oil is a different product.

**References:**
- Ricin and Ricinus communis in pharmacology and toxicology—from ancient use to modern perspectives (2019). https://pubmed.ncbi.nlm.nih.gov/31359089/
- Ricinus communis intoxications in human and veterinary medicine—a summary of real cases (2011). https://pubmed.ncbi.nlm.nih.gov/22069699/

## Curry_Leaf — Curry leaf
**Scientific name:** Murraya koenigii  
**Taxonomy confidence:** high  
**Taxonomy note:** Curry leaf/sweet neem corresponds to Murraya koenigii.

**Traditional uses reported:**
- Piles/hemorrhoids in traditional use
- Inflammation, itching and fresh cuts
- Dysentery and amoebiasis-related traditional use
- Diabetes-related traditional use
- Hepatitis-related traditional use

**Treatment context:** Fresh leaves and combinations with foods are reported in Ayurveda/folk practice; this package does not reproduce recipes.

**Safety:** Do not use traditional claims to self-treat diabetes, hepatitis or serious gastrointestinal disease. Evidence is largely preclinical for many outcomes.

**References:**
- Murraya koenigii (L.) Spreng. as a Natural Intervention for Diabesity: A Review (2024). https://pubmed.ncbi.nlm.nih.gov/39253925/ https://doi.org/10.2174/0113816128304471240801183021

## Doddapatre — Doddapatre / Indian borage
**Scientific name:** Plectranthus amboinicus (syn. Coleus amboinicus)  
**Taxonomy confidence:** high  
**Taxonomy note:** Doddapatre commonly refers to Plectranthus/Coleus amboinicus in Karnataka and South India.

**Traditional uses reported:**
- Cough, sore throat and nasal congestion
- Asthma and bronchitis-related traditional use
- Digestive complaints and constipation
- Topical use for burns, bruises, inflammation and insect bites

**Treatment context:** Leaves and aromatic preparations are commonly described ethnomedicinally; no dose is provided.

**Safety:** Respiratory symptoms can require urgent medical care. Essential oils/concentrated extracts can have different risks from culinary leaf use.

**References:**
- Plectranthus amboinicus: A Systematic Review of Traditional Uses, Phytochemical Properties, and Therapeutic Applications (2025). https://pubmed.ncbi.nlm.nih.gov/40430526/ https://doi.org/10.3390/ph18050707

## Ekka — Ekka / Giant milkweed
**Scientific name:** Calotropis gigantea (probable)  
**Taxonomy confidence:** probable  
**Taxonomy note:** The common name “Ekka” can refer to Calotropis species; C. gigantea is a probable mapping, but C. procera can also be called by related vernacular names.

**Traditional uses reported:**
- Pain
- Inflammation
- Wounds
- Infections in traditional use

**Treatment context:** Traditional use includes latex, leaves, flowers and bark in different systems. This package intentionally gives no preparation instructions.

**Safety:** HIGH-RISK: Calotropis contains cardiac glycosides/cardenolides and irritating latex. Do not ingest or use as a home treatment; species identity and toxicity are critical.

**References:**
- From traditional uses to biochemical evidence: phytochemical diversity and bioactivities of Calotropis gigantea—a comprehensive update since 2013 (2026). https://pubmed.ncbi.nlm.nih.gov/42566010/ https://doi.org/10.1007/s00044-026-03602-w

## Ganike — Ganike / Black nightshade
**Scientific name:** Solanum nigrum  
**Taxonomy confidence:** high  
**Taxonomy note:** “Ganike” is used for Solanum nigrum in regional Indian plant-name sources.

**Traditional uses reported:**
- Sore throat and toothache
- Dermatitis, eczema, boils/carbuncles
- Urinary/urethral complaints
- Traditional use reports also include cancers and kidney-related complaints

**Treatment context:** Different plant parts and maturity stages are used in folk traditions; no preparation details are supplied.

**Safety:** Nightshade species and plant maturity matter because glycoalkaloid content varies. Do not use this entry as a cancer or kidney-disease treatment recommendation.

**References:**
- Solanum nigrum Linn.: An Insight into Current Research on Traditional Uses, Phytochemistry, and Pharmacology (2022). https://pubmed.ncbi.nlm.nih.gov/36052142/ https://doi.org/10.3389/fphar.2022.918071

## Gauva — Guava
**Scientific name:** Psidium guajava  
**Taxonomy confidence:** high  
**Taxonomy note:** The dataset spelling “Gauva” corresponds to guava, Psidium guajava.

**Traditional uses reported:**
- Diarrhea and dysentery
- Traditional hypoglycemic/diabetes-related use
- Cough
- Skin ulcers/wound-related traditional use

**Treatment context:** Leaves and fruits are frequently used in folk medicine; the best documented traditional GI use is for diarrhea/dysentery.

**Safety:** Persistent diarrhea, blood in stool, dehydration or diabetes require medical assessment. Concentrated extracts are not equivalent to eating guava fruit.

**References:**
- Psidium guajava: a review of its traditional uses, phytochemistry and pharmacology (2008). https://pubmed.ncbi.nlm.nih.gov/18353572/ https://doi.org/10.1016/j.jep.2008.01.025

## Geranium — Geranium
**Scientific name:** Geranium spp. / Pelargonium spp. (dataset species unspecified)  
**Taxonomy confidence:** ambiguous  
**Taxonomy note:** The label “Geranium” does not encode a species and common usage can also refer to Pelargonium. The citation is genus-level Geranium literature.

**Traditional uses reported:**
- Wound/skin-related ethnomedicinal use
- Pain and inflammation-related use
- Gastrointestinal complaints
- Respiratory complaints in various traditional systems

**Treatment context:** Use varies greatly by Geranium/Pelargonium species. This entry is intentionally genus-level.

**Safety:** Do not transfer a medicinal claim from one Geranium/Pelargonium species to another without botanical verification.

**References:**
- The geranium genus: A comprehensive study on ethnomedicinal uses, phytochemical compounds, and pharmacological importance (2024). https://pubmed.ncbi.nlm.nih.gov/38371877/ https://doi.org/10.1016/j.sjbs.2024.103940

## Henna — Henna
**Scientific name:** Lawsonia inermis  
**Taxonomy confidence:** high  
**Taxonomy note:** Henna corresponds to Lawsonia inermis.

**Traditional uses reported:**
- Topical protection/treatment for fungal skin problems in traditional use
- Lice and dandruff
- Ulcers and wound-related use
- Traditional liver and digestive complaints

**Treatment context:** Traditional use is largely topical for dyeing and skin/hair care, with additional internal uses reported historically.

**Safety:** Adverse skin reactions occur; “black henna” may contain para-phenylenediamine (PPD) and is not equivalent to pure henna. G6PD deficiency is a special safety concern.

**References:**
- Lawsonia inermis L. (henna): ethnobotanical, phytochemical and pharmacological aspects (2014). https://pubmed.ncbi.nlm.nih.gov/24886774/ https://doi.org/10.1016/j.jep.2014.05.042

## Hibiscus — Hibiscus / China rose
**Scientific name:** Hibiscus rosa-sinensis  
**Taxonomy confidence:** high  
**Taxonomy note:** The medicinal-plant dataset mapping commonly uses Hibiscus rosa-sinensis for this class.

**Traditional uses reported:**
- Traditional women’s/reproductive-health uses
- Fever and inflammation-related use
- Hair and scalp care
- Skin/wound-related traditional use

**Treatment context:** Flowers, leaves and other parts are used in different traditional systems; the women’s-health literature documents H. rosa-sinensis among repeatedly reported species.

**Safety:** Reproductive effects are among reported pharmacological areas; pregnancy/fertility contexts require professional advice rather than self-treatment.

**References:**
- A Comprehensive Overview of Hibiscus rosa-sinensis L.: Its Ethnobotanical Uses, Phytochemistry, Therapeutic Uses, Pharmacological Activities, and Toxicology (2024). https://pubmed.ncbi.nlm.nih.gov/37218183/ https://doi.org/10.2174/1871530323666230522113405
- Medicinal plants for women’s healthcare in southeast Asia: a meta-analysis of their traditional use, chemical constituents, and pharmacology (2014). https://pubmed.ncbi.nlm.nih.gov/24269772/ https://doi.org/10.1016/j.jep.2013.11.030

## Honge — Honge / Indian beech
**Scientific name:** Pongamia pinnata (syn. Millettia pinnata) (probable)  
**Taxonomy confidence:** probable  
**Taxonomy note:** “Honge” commonly refers to Pongamia pinnata in Karnataka, although vernacular-name overlap exists.

**Traditional uses reported:**
- Piles/hemorrhoids
- Skin diseases
- Wounds
- Inflammation-related traditional use

**Treatment context:** Multiple plant parts and oils are described traditionally; this entry does not give preparation or dosing instructions.

**Safety:** Seeds/oils and concentrated extracts should not be ingested casually. Botanical identity should be confirmed before displaying medicinal information.

**References:**
- Medicinal uses, phytochemistry and pharmacology of Pongamia pinnata (L.) Pierre: a review (2013). https://pubmed.ncbi.nlm.nih.gov/24016802/ https://doi.org/10.1016/j.jep.2013.08.041

## Insulin — Insulin plant
**Scientific name:** Costus igneus / Costus pictus complex  
**Taxonomy confidence:** high  
**Taxonomy note:** The “Insulin plant” label is widely used for Costus igneus; literature also discusses Costus pictus in this context.

**Traditional uses reported:**
- Dietary/traditional use for diabetes and blood-glucose control

**Treatment context:** Leaves are reported as a dietary supplement in southern India. The cited review explicitly notes interest in anti-diabetic potential.

**Safety:** Do not replace diabetes medication or monitoring with this plant. Combining glucose-lowering products may increase hypoglycemia risk; human evidence is not conclusive.

**References:**
- A review on Insulin plant (Costus igneus Nak) (2014). https://pubmed.ncbi.nlm.nih.gov/24600198/ https://doi.org/10.4103/0973-7847.125536

## Jasmine — Jasmine
**Scientific name:** Jasminum spp. (representative source: Jasminum sambac)  
**Taxonomy confidence:** ambiguous  
**Taxonomy note:** The class label does not identify a species. The cited paper is for Jasminum sambac and should be treated as representative, not a confirmed species mapping.

**Traditional uses reported:**
- Insomnia and headache in J. sambac traditional use
- Dental complaints
- Bruises
- Diarrhea and abdominal pain
- Dizziness and difficult-labor related traditional use

**Treatment context:** Uses are species- and region-specific. The app should display a taxonomy-warning badge for this class.

**Safety:** Do not transfer the cited J. sambac uses to all jasmine species. Pregnancy/labor-related claims are especially unsuitable for self-treatment.

**References:**
- Jasminum sambac: Progress in research on ethnopharmacology, phytochemistry, pharmacological actions and other applications (2026). https://pubmed.ncbi.nlm.nih.gov/40882791/ https://doi.org/10.1016/j.jep.2025.120478

## Lemon — Lemon
**Scientific name:** Citrus limon  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label corresponds to Citrus limon.

**Traditional uses reported:**
- Common cold and sore-throat related traditional use
- Fever
- Scurvy prevention/treatment historically through vitamin-C-rich citrus use
- Rheumatism and pain-related folk use

**Treatment context:** Fruit juice/peel/essential oil have distinct traditional and modern uses.

**Safety:** Citrus essential oils and some raw materials can be phototoxic on skin; concentrated oil is not equivalent to food use.

**References:**
- Citrus limon (Lemon) Phenomenon—A Review of the Chemistry, Pharmacological Properties, Applications in the Modern Pharmaceutical, Food, and Cosmetics Industries, and Biotechnological Studies (2020). https://pubmed.ncbi.nlm.nih.gov/31963590/ https://doi.org/10.3390/plants9010119

## Lemon_grass — Lemongrass
**Scientific name:** Cymbopogon citratus  
**Taxonomy confidence:** high  
**Taxonomy note:** Lemongrass in medicinal datasets most commonly maps to Cymbopogon citratus.

**Traditional uses reported:**
- Cold, cough and sore throat
- Headache and dizziness
- Loss of appetite and abdominal pain
- Diarrhea
- Rheumatism-related traditional use

**Treatment context:** Traditionally consumed as aromatic herbal preparations and used externally in some cultures; no recipe or dose is included.

**Safety:** Human clinical evidence is limited for many conditions. Essential oil is concentrated and can irritate skin or interact with medications.

**References:**
- Ethnobotanical uses, phytochemistry and bioactivities of Cymbopogon plants: A review (2024). https://pubmed.ncbi.nlm.nih.gov/38608798/ https://doi.org/10.1016/j.jep.2024.118181
- Scientific basis for the therapeutic use of Cymbopogon citratus, stapf (Lemon grass) (2011). https://pubmed.ncbi.nlm.nih.gov/22171285/ https://doi.org/10.4103/2231-4040.79796

## Mango — Mango
**Scientific name:** Mangifera indica  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label corresponds to Mangifera indica.

**Traditional uses reported:**
- Diarrhea and dysentery
- Fever
- Traditional diabetes-related use
- Inflammatory complaints
- Parasitic/infectious complaints in some ethnomedicinal traditions

**Treatment context:** Leaves, bark, fruit, peel, seed and other parts have distinct traditional applications.

**Safety:** Evidence differs greatly by plant part and preparation. Mango extracts should not replace treatment for diabetes, infection or inflammatory disease.

**References:**
- A Review on Ethnopharmacological Applications, Pharmacological Activities, and Bioactive Compounds of Mangifera indica (Mango) (2017). https://pubmed.ncbi.nlm.nih.gov/29456572/ https://doi.org/10.1155/2017/6949835

## Mint — Mint
**Scientific name:** Mentha spp. (representative source: Mentha spicata)  
**Taxonomy confidence:** ambiguous  
**Taxonomy note:** The class label does not identify a species. The representative citation is spearmint (Mentha spicata).

**Traditional uses reported:**
- Cold and cough
- Asthma-related traditional use
- Fever
- Digestive problems
- Jaundice and other folk uses reported for spearmint

**Treatment context:** Mint species vary chemically; culinary leaves and concentrated essential oils should not be treated as interchangeable.

**Safety:** Species confirmation is needed. Peppermint/spearmint oils can cause adverse effects and may be unsuitable for some children or medication users.

**References:**
- The traditional uses, phytochemistry and pharmacology of spearmint (Mentha spicata L.): A review (2021). https://pubmed.ncbi.nlm.nih.gov/34087400/ https://doi.org/10.1016/j.jep.2021.114266

## Nagadali — Nagadali / Rue
**Scientific name:** Ruta graveolens  
**Taxonomy confidence:** high  
**Taxonomy note:** Regional medicinal-plant sources commonly map Nagadali to Ruta graveolens.

**Traditional uses reported:**
- Cold-related fever
- Toothache and headache
- Bruises and sprains
- Irregular menstruation
- Infantile eczema in traditional reports

**Treatment context:** Historical use includes topical and internal preparations; this package intentionally gives no instructions.

**Safety:** HIGH-RISK: Ruta graveolens has documented phototoxicity and pregnancy toxicity/abortifacient risk. It should not be used in pregnancy or as a home treatment.

**References:**
- Traditional Uses, Phytochemistry, Pharmacology and Toxicology of Ruta graveolens L.: A Critical Review and Future Perspectives (2024). https://pubmed.ncbi.nlm.nih.gov/39758226/ https://doi.org/10.2147/DDDT.S494417
- Is it safe to consume traditional medicinal plants during pregnancy? (2021). https://pubmed.ncbi.nlm.nih.gov/33164294/

## Neem — Neem
**Scientific name:** Azadirachta indica  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label is unambiguous for Azadirachta indica.

**Traditional uses reported:**
- Skin conditions and wound-related traditional use
- Oral/dental hygiene traditions
- Fever/infectious-disease related traditional use
- Inflammation-related traditional use

**Treatment context:** Leaves, bark, twigs, seed oil and other parts have different traditional uses and risk profiles.

**Safety:** Neem products are not interchangeable; ingestion of concentrated seed oil can be hazardous. Do not use for serious infection or chronic disease without medical guidance.

**References:**
- Neem (Azadirachta indica): prehistory to contemporary medicinal uses to humankind (2013). https://pubmed.ncbi.nlm.nih.gov/23835719/ https://doi.org/10.1016/S2221-1691(13)60105-7

## Nithyapushpa — Nithyapushpa / Madagascar periwinkle
**Scientific name:** Catharanthus roseus (probable)  
**Taxonomy confidence:** probable  
**Taxonomy note:** “Nithyapushpa/Nityapushpa” commonly denotes Catharanthus roseus in Indian vernacular usage.

**Traditional uses reported:**
- Traditional diabetes use
- Stomach disorders
- Kidney and liver complaints
- Cardiovascular complaints
- Traditional cancer-related use

**Treatment context:** Traditional claims are historically important because research on the plant led to isolation of vinca alkaloids used as prescription anticancer drugs.

**Safety:** HIGH-RISK: The whole plant contains potent alkaloids. Vincristine/vinblastine are purified prescription medicines with significant toxicity; home-made periwinkle preparations are not cancer treatments and should not be ingested for self-medication.

**References:**
- Catharanthus roseus (L.) G. Don: A review of its ethnobotany, phytochemistry, ethnopharmacology and toxicities (2022). https://pubmed.ncbi.nlm.nih.gov/34562562/ https://doi.org/10.1016/j.jep.2021.114647
- Vinca Alkaloid Toxicity (2024). https://pubmed.ncbi.nlm.nih.gov/32491774/

## Nooni — Noni / Nooni
**Scientific name:** Morinda citrifolia  
**Taxonomy confidence:** high  
**Taxonomy note:** Nooni/Noni corresponds to Morinda citrifolia.

**Traditional uses reported:**
- Pain and inflammation-related traditional use
- Wound and skin-related use
- Gastrointestinal complaints
- Diabetes-related traditional use
- Antimicrobial/infection-related traditional use

**Treatment context:** Fruit, leaf, root and other parts appear in ethnomedicinal practice; modern studies are still heterogeneous.

**Safety:** Evidence for treating disease is not established for many uses. People with chronic illness or taking medicines should review interactions and organ-safety concerns with a clinician.

**References:**
- Botany, Ethnomedicinal Uses, Biological Activities, Phytochemistry, and Technological Applications of Morinda citrifolia Plants (2025). https://pubmed.ncbi.nlm.nih.gov/41011723/ https://doi.org/10.3390/molecules30183831

## Pappaya — Papaya
**Scientific name:** Carica papaya  
**Taxonomy confidence:** high  
**Taxonomy note:** The dataset spelling “Pappaya” corresponds to Carica papaya.

**Traditional uses reported:**
- Inflammation and pain
- Hypertension
- Diabetes
- Dermatitis
- Asthma
- Stomach problems

**Treatment context:** Fruit, leaves, seeds, latex and other parts have distinct traditional uses; no preparation instructions are given.

**Safety:** The cited review emphasizes that toxicity, efficacy and clinical trials are still needed before therapeutic use. Latex/unripe-papaya preparations require extra caution, especially in pregnancy.

**References:**
- Carica papaya in health and disease: a review of its bioactive compounds for treating various disease conditions, including anti-inflammatory and anti-arthritic activities (2025). https://pubmed.ncbi.nlm.nih.gov/40392387/ https://doi.org/10.1007/s10787-025-01780-4
- Is it safe to consume traditional medicinal plants during pregnancy? (2021). https://pubmed.ncbi.nlm.nih.gov/33164294/

## Pepper — Black pepper
**Scientific name:** Piper nigrum  
**Taxonomy confidence:** high  
**Taxonomy note:** The medicinal dataset label “Pepper” is most consistent with black pepper, Piper nigrum.

**Traditional uses reported:**
- Menstrual complaints in Indian folk reports
- Ear-nose-throat complaints
- Digestive/gastrointestinal traditional use
- Cold/cough-related spice-medicine use

**Treatment context:** Fruits/seeds are commonly used as spice and in traditional formulas; concentrated piperine is pharmacologically different from culinary quantities.

**Safety:** Piperine can alter drug absorption/metabolism. Do not use concentrated extracts to replace prescribed therapy.

**References:**
- A systematic review on black pepper (Piper nigrum L.): from folk uses to pharmacological applications (2019). https://pubmed.ncbi.nlm.nih.gov/30740986/ https://doi.org/10.1080/10408398.2019.1565489

## Pomegranate — Pomegranate
**Scientific name:** Punica granatum  
**Taxonomy confidence:** high  
**Taxonomy note:** The class label corresponds to Punica granatum.

**Traditional uses reported:**
- Peptic-ulcer related traditional use
- Oral diseases
- Traditional use for diabetes, hypertension and hyperlipidemia
- Atherosclerosis-related traditional use
- Traditional cancer-related use in several medical systems

**Treatment context:** Fruit, rind, flower, bark and other parts have different compositions; this dataset summarizes indications rather than formulations.

**Safety:** Traditional use for cardiometabolic disease or cancer is not proof of clinical efficacy and should not replace standard treatment.

**References:**
- A unique understanding of traditional medicine of pomegranate, Punica granatum L. and its current research status (2021). https://pubmed.ncbi.nlm.nih.gov/33515685/ https://doi.org/10.1016/j.jep.2021.113877

## Raktachandini — Raktachandini / Red sandalwood
**Scientific name:** Pterocarpus santalinus (probable)  
**Taxonomy confidence:** probable  
**Taxonomy note:** Raktachandan/Rakta Chandana commonly refers to red sandalwood, Pterocarpus santalinus.

**Traditional uses reported:**
- Inflammatory disorders
- Dermatological/skin complaints
- Gastrointestinal complaints in traditional systems
- Metabolic-disorder related traditional use

**Treatment context:** The heartwood is particularly prominent in traditional Ayurvedic use.

**Safety:** Traditional anti-inflammatory use is better documented than human clinical efficacy. Product identity/adulteration and conservation status should be considered.

**References:**
- Traditional uses, phytochemistry and pharmacological attributes of Pterocarpus santalinus and future directions: A review (2021). https://pubmed.ncbi.nlm.nih.gov/33915135/ https://doi.org/10.1016/j.jep.2021.114127

## Rose — Rose
**Scientific name:** Rosa spp. (representative source: Rosa damascena)  
**Taxonomy confidence:** ambiguous  
**Taxonomy note:** The class label does not identify a rose species. The cited medicinal review is for Rosa damascena and is representative only.

**Traditional uses reported:**
- Chest and abdominal pain in R. damascena traditional use
- Constipation and digestive disorders
- Menstrual bleeding complaints
- Liver ailments
- Aromatic calming/comfort uses in traditional practice

**Treatment context:** Rose species, hips, petals and oils are chemically different; display a taxonomy warning in the app.

**Safety:** Do not generalize medicinal claims from R. damascena to every Rosa species. Essential oils can irritate or cause allergy.

**References:**
- Chemical constituents, experimental and clinical pharmacology of Rosa damascena: a literature review (2020). https://pubmed.ncbi.nlm.nih.gov/31709541/ https://doi.org/10.1111/jphp.13185

## Sapota — Sapota / Sapodilla
**Scientific name:** Manilkara zapota  
**Taxonomy confidence:** high  
**Taxonomy note:** Sapota/sapodilla corresponds to Manilkara zapota.

**Traditional uses reported:**
- Diarrhea and dysentery
- Fever
- Cold and cough
- Indigestion
- Wounds and ulcers
- Traditional bladder/kidney-stone-related use of seeds

**Treatment context:** Different structures—fruit, leaves, seeds and bark—have distinct traditional uses.

**Safety:** Clinical trials are limited for many applications. Seeds and extracts should not be used as do-it-yourself stone treatments.

**References:**
- Manilkara zapota “chicozapote” as a fruit source of health-beneficial bioactive compounds and its effects on chronic degenerative and infectious diseases, a review (2023). https://pubmed.ncbi.nlm.nih.gov/37469550/ https://doi.org/10.3389/fnut.2023.1194283
- A systematic review on traditional use, phytochemistry and pharmacological activities of Manilkara zapota (2024). https://doi.org/10.1016/j.prenap.2024.100062 https://doi.org/10.1016/j.prenap.2024.100062

## Tulasi — Tulasi / Holy basil
**Scientific name:** Ocimum tenuiflorum (syn. Ocimum sanctum)  
**Taxonomy confidence:** high  
**Taxonomy note:** Tulasi/Tulsi corresponds to Ocimum tenuiflorum; Ocimum sanctum is a widely used synonym in older literature.

**Traditional uses reported:**
- Bronchitis and bronchial asthma
- Malaria and chronic/catarrhal fever in traditional use
- Diarrhea and dysentery
- Skin diseases
- Arthritis
- Insect bites

**Treatment context:** Leaves and other parts are used in Ayurveda and folk medicine, often in compound preparations.

**Safety:** Traditional use does not establish clinical efficacy for malaria, asthma or serious infection. Medication interactions and pregnancy context require professional advice.

**References:**
- Therapeutic uses of Ocimum sanctum Linn (Tulsi) with a note on eugenol and its pharmacological actions: a short review (2005). https://pubmed.ncbi.nlm.nih.gov/16170979/
- A Comprehensive Review of the Phytochemical Constituents and Bioactivities of Ocimum tenuiflorum (2024). https://pubmed.ncbi.nlm.nih.gov/39473808/

## Wood_sorel — Wood sorrel
**Scientific name:** Oxalis corniculata (probable)  
**Taxonomy confidence:** probable  
**Taxonomy note:** Wood sorrel in Indian medicinal contexts commonly refers to Oxalis corniculata, but the generic common name can cover other Oxalis species.

**Traditional uses reported:**
- Gastrointestinal discomfort
- Fever
- Urinary complaints
- Liver-related traditional use
- Topical use for warts, eczema, wounds and abscesses

**Treatment context:** Whole-plant and topical uses are described traditionally; exact species identification matters.

**Safety:** Oxalis contains oxalates and concentrated medicinal use is not the same as incidental food exposure. Pregnancy use should not be assumed safe.

**References:**
- A Review on Phyto-pharmacology of Oxalis corniculata (2022). https://pubmed.ncbi.nlm.nih.gov/34391377/ https://doi.org/10.2174/1386207324666210813121431
- Is it safe to consume traditional medicinal plants during pregnancy? (2021). https://pubmed.ncbi.nlm.nih.gov/33164294/
