# Nooni — Noni / Nooni

**Scientific name:** Morinda citrifolia
**Taxonomy confidence:** high
**Taxonomy note:** Nooni/Noni corresponds to Morinda citrifolia.

## Traditional uses reported in the literature
- Pain and inflammation-related traditional use
- Wound and skin-related use
- Gastrointestinal complaints
- Diabetes-related traditional use
- Antimicrobial/infection-related traditional use

## Traditional treatment context
Fruit, leaf, root and other parts appear in ethnomedicinal practice; modern studies are still heterogeneous.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Evidence for treating disease is not established for many uses. People with chronic illness or taking medicines should review interactions and organ-safety concerns with a clinician.

## References
1. Nascimento Júnior JAC, et al. Molecules. 2025;30(18):3831. *Botany, Ethnomedicinal Uses, Biological Activities, Phytochemistry, and Technological Applications of Morinda citrifolia Plants*. DOI: https://doi.org/10.3390/molecules30183831 Online: https://pubmed.ncbi.nlm.nih.gov/41011723/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
