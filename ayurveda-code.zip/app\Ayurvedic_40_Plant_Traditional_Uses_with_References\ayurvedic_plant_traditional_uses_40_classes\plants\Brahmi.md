# Brahmi — Brahmi

**Scientific name:** Bacopa monnieri
**Taxonomy confidence:** probable
**Taxonomy note:** “Brahmi” can be used for more than one herb regionally; in medicinal-plant ML datasets it commonly denotes Bacopa monnieri.

## Traditional uses reported in the literature
- Memory and learning enhancement in Ayurveda
- Sedative/calming traditional use
- Traditional anti-epileptic use
- Cognitive and nervous-system support

## Traditional treatment context
Bacopa preparations are widely discussed in Ayurveda and modern supplement research; this dataset does not provide doses.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Can cause adverse effects or interact with medicines. It should not replace treatment for epilepsy, cognitive disorders or psychiatric conditions.

## References
1. Fatima U, et al. Frontiers in Nutrition. 2022;9:972379. *Pharmacological attributes of Bacopa monnieri extract: Current updates and clinical manifestation*. DOI: https://doi.org/10.3389/fnut.2022.972379 Online: https://pubmed.ncbi.nlm.nih.gov/36061899/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
