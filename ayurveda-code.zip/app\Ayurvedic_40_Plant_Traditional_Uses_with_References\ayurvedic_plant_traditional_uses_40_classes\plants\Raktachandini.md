# Raktachandini — Raktachandini / Red sandalwood

**Scientific name:** Pterocarpus santalinus (probable)
**Taxonomy confidence:** probable
**Taxonomy note:** Raktachandan/Rakta Chandana commonly refers to red sandalwood, Pterocarpus santalinus.

## Traditional uses reported in the literature
- Inflammatory disorders
- Dermatological/skin complaints
- Gastrointestinal complaints in traditional systems
- Metabolic-disorder related traditional use

## Traditional treatment context
The heartwood is particularly prominent in traditional Ayurvedic use.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Traditional anti-inflammatory use is better documented than human clinical efficacy. Product identity/adulteration and conservation status should be considered.

## References
1. Dahat Y, et al. Journal of Ethnopharmacology. 2021;276:114127. *Traditional uses, phytochemistry and pharmacological attributes of Pterocarpus santalinus and future directions: A review*. DOI: https://doi.org/10.1016/j.jep.2021.114127 Online: https://pubmed.ncbi.nlm.nih.gov/33915135/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
