# Taxonomy / class-label warnings

These warnings are important because ImageFolder class names are common labels, not a botanical authority. Your app should avoid showing species-specific medicinal information as definitive where the class label is ambiguous.

## Bamboo
- Proposed mapping: **Bambusoideae spp.**
- Confidence: **ambiguous**
- Note: “Bamboo” is a subfamily-level/common label and does not encode a single species. The cited paper is a broad bamboo-leaf review.

## Brahmi
- Proposed mapping: **Bacopa monnieri**
- Confidence: **probable**
- Note: “Brahmi” can be used for more than one herb regionally; in medicinal-plant ML datasets it commonly denotes Bacopa monnieri.

## Ekka
- Proposed mapping: **Calotropis gigantea (probable)**
- Confidence: **probable**
- Note: The common name “Ekka” can refer to Calotropis species; C. gigantea is a probable mapping, but C. procera can also be called by related vernacular names.

## Geranium
- Proposed mapping: **Geranium spp. / Pelargonium spp. (dataset species unspecified)**
- Confidence: **ambiguous**
- Note: The label “Geranium” does not encode a species and common usage can also refer to Pelargonium. The citation is genus-level Geranium literature.

## Honge
- Proposed mapping: **Pongamia pinnata (syn. Millettia pinnata) (probable)**
- Confidence: **probable**
- Note: “Honge” commonly refers to Pongamia pinnata in Karnataka, although vernacular-name overlap exists.

## Jasmine
- Proposed mapping: **Jasminum spp. (representative source: Jasminum sambac)**
- Confidence: **ambiguous**
- Note: The class label does not identify a species. The cited paper is for Jasminum sambac and should be treated as representative, not a confirmed species mapping.

## Mint
- Proposed mapping: **Mentha spp. (representative source: Mentha spicata)**
- Confidence: **ambiguous**
- Note: The class label does not identify a species. The representative citation is spearmint (Mentha spicata).

## Nithyapushpa
- Proposed mapping: **Catharanthus roseus (probable)**
- Confidence: **probable**
- Note: “Nithyapushpa/Nityapushpa” commonly denotes Catharanthus roseus in Indian vernacular usage.

## Raktachandini
- Proposed mapping: **Pterocarpus santalinus (probable)**
- Confidence: **probable**
- Note: Raktachandan/Rakta Chandana commonly refers to red sandalwood, Pterocarpus santalinus.

## Rose
- Proposed mapping: **Rosa spp. (representative source: Rosa damascena)**
- Confidence: **ambiguous**
- Note: The class label does not identify a rose species. The cited medicinal review is for Rosa damascena and is representative only.

## Wood_sorel
- Proposed mapping: **Oxalis corniculata (probable)**
- Confidence: **probable**
- Note: Wood sorrel in Indian medicinal contexts commonly refers to Oxalis corniculata, but the generic common name can cover other Oxalis species.
