# Mint — Mint

**Scientific name:** Mentha spp. (representative source: Mentha spicata)
**Taxonomy confidence:** ambiguous
**Taxonomy note:** The class label does not identify a species. The representative citation is spearmint (Mentha spicata).

## Traditional uses reported in the literature
- Cold and cough
- Asthma-related traditional use
- Fever
- Digestive problems
- Jaundice and other folk uses reported for spearmint

## Traditional treatment context
Mint species vary chemically; culinary leaves and concentrated essential oils should not be treated as interchangeable.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Species confirmation is needed. Peppermint/spearmint oils can cause adverse effects and may be unsuitable for some children or medication users.

## References
1. Mahendran G, Verma SK, Rahman L-U. Journal of Ethnopharmacology. 2021;278:114266. *The traditional uses, phytochemistry and pharmacology of spearmint (Mentha spicata L.): A review*. DOI: https://doi.org/10.1016/j.jep.2021.114266 Online: https://pubmed.ncbi.nlm.nih.gov/34087400/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
