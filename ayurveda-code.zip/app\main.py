from pathlib import Path
import logging, os, uuid
from io import BytesIO

from fastapi.staticfiles import StaticFiles
from fastapi import FastAPI, File, UploadFile, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from PIL import Image, UnidentifiedImageError
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.config import settings
from app.predictor import predict_plant
from app.plant_info import get_catalogue, get_statistics, get_plant_information

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ayurvedic-ai")

limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title=settings.app_name)

STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

app.add_middleware(SlowAPIMiddleware)
app.state.limiter = limiter

origins = [x.strip() for x in settings.allowed_origins.split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        # Google Fonts needs stylesheet + font origins. Scripts stay locked to
        # 'self' — the UI animates with CSS/Web Animations, no CDN libraries.
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data:; "
            "style-src 'self' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "script-src 'self'; connect-src 'self'"
        )
        return response

app.add_middleware(SecurityHeadersMiddleware)

templates = Jinja2Templates(directory="app/templates")

FAQ = [
    ("What is Ayurveda?", "Ayurveda is a traditional system of medicine originating in South Asia. This application describes traditional uses as historical/traditional information, not as proof of clinical effectiveness."),
    ("Can the AI identify any plant?", "No. The model can only reliably predict classes represented in the training dataset. Always treat the prediction as uncertain and verify the plant with a qualified expert."),
    ("Can I use the plant as a treatment?", "Do not use an AI prediction as a treatment instruction. Traditional-use information is not a substitute for professional medical or Ayurvedic advice."),
    ("What are ingredients/constituents?", "The system can display documented plant constituents when supported by the research sources you provide. Constituents do not automatically establish a therapeutic effect."),
    ("Where does the information come from?", "The final version should cite the research papers and authoritative sources supplied for the project. The starter app intentionally does not invent evidence."),
]

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "request": request,
            "faq": FAQ,
            "stats": get_statistics(),
        }
    )


@app.get("/api/plants")
async def plants():
    return JSONResponse({
        "plants": get_catalogue(),
        "statistics": get_statistics(),
    })


@app.get("/api/plants/{class_label}")
async def plant_detail(class_label: str):
    plant = get_plant_information(class_label)

    if plant is None:
        return JSONResponse({"error": "Unknown plant."}, status_code=404)

    return JSONResponse(plant)
@app.post("/predict")
@limiter.limit(settings.rate_limit)
async def predict(request: Request, file: UploadFile = File(...)):
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if not file.filename:
        return JSONResponse({"error": "No file selected."}, status_code=400)

    ext = Path(file.filename).suffix.lower()
    allowed = {".jpg", ".jpeg", ".png", ".webp"}
    if ext not in allowed:
        return JSONResponse({"error": "Only JPG, JPEG, PNG and WebP images are allowed."}, status_code=400)

    data = await file.read(max_bytes + 1)
    if len(data) > max_bytes:
        return JSONResponse({"error": f"Image exceeds {settings.max_upload_mb} MB."}, status_code=413)

    try:
        image = Image.open(BytesIO(data))
        image.verify()
        image = Image.open(BytesIO(data)).convert("RGB")
    except (UnidentifiedImageError, OSError):
        return JSONResponse({"error": "The uploaded file is not a valid image."}, status_code=400)

    # The original filename is never used as a filesystem path.
    temp_name = f"{uuid.uuid4().hex}.jpg"
    logger.info("Plant image received: %s (%d bytes)", temp_name, len(data))

    result = predict_plant(image)
    return JSONResponse(result)

@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse({"error": "Too many requests. Please try again shortly."}, status_code=429)
