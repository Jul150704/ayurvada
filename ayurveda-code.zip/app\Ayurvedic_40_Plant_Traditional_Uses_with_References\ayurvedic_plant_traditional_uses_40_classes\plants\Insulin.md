# Insulin — Insulin plant

**Scientific name:** Costus igneus / Costus pictus complex
**Taxonomy confidence:** high
**Taxonomy note:** The “Insulin plant” label is widely used for Costus igneus; literature also discusses Costus pictus in this context.

## Traditional uses reported in the literature
- Dietary/traditional use for diabetes and blood-glucose control

## Traditional treatment context
Leaves are reported as a dietary supplement in southern India. The cited review explicitly notes interest in anti-diabetic potential.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Do not replace diabetes medication or monitoring with this plant. Combining glucose-lowering products may increase hypoglycemia risk; human evidence is not conclusive.

## References
1. Hegde PK, Rao HA, Rao PN. Pharmacognosy Reviews. 2014;8(15):67-72. *A review on Insulin plant (Costus igneus Nak)*. DOI: https://doi.org/10.4103/0973-7847.125536 Online: https://pubmed.ncbi.nlm.nih.gov/24600198/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
