# Bamboo — Bamboo

**Scientific name:** Bambusoideae spp.
**Taxonomy confidence:** ambiguous
**Taxonomy note:** “Bamboo” is a subfamily-level/common label and does not encode a single species. The cited paper is a broad bamboo-leaf review.

## Traditional uses reported in the literature
- Cough and cold-related complaints
- Fever
- Rheumatism/inflammatory complaints
- Skin-related traditional uses
- Traditional use for influenza-like symptoms

## Traditional treatment context
Bamboo leaves are used in several traditional systems; species, plant part and preparation differ substantially.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Species-level identification is required before any medicinal interpretation. Some bamboo species/parts may have distinct safety profiles; pregnancy use should not be assumed safe.

## References
1. Cheng Y, et al. Journal of Ethnopharmacology. 2023;306:116166. *Bamboo leaf: A review of traditional medicinal property, phytochemistry, pharmacology, and purification technology*. DOI: https://doi.org/10.1016/j.jep.2023.116166 Online: https://pubmed.ncbi.nlm.nih.gov/36649850/
2. Review indexed in PubMed (PMID 33164294). *Is it safe to consume traditional medicinal plants during pregnancy?*. Online: https://pubmed.ncbi.nlm.nih.gov/33164294/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
