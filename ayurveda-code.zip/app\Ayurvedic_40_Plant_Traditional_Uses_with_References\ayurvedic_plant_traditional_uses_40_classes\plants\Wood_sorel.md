# Wood_sorel — Wood sorrel

**Scientific name:** Oxalis corniculata (probable)
**Taxonomy confidence:** probable
**Taxonomy note:** Wood sorrel in Indian medicinal contexts commonly refers to Oxalis corniculata, but the generic common name can cover other Oxalis species.

## Traditional uses reported in the literature
- Gastrointestinal discomfort
- Fever
- Urinary complaints
- Liver-related traditional use
- Topical use for warts, eczema, wounds and abscesses

## Traditional treatment context
Whole-plant and topical uses are described traditionally; exact species identification matters.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Oxalis contains oxalates and concentrated medicinal use is not the same as incidental food exposure. Pregnancy use should not be assumed safe.

## References
1. Sarfraz I, et al. Combinatorial Chemistry & High Throughput Screening. 2022;25(7):1181-1186. *A Review on Phyto-pharmacology of Oxalis corniculata*. DOI: https://doi.org/10.2174/1386207324666210813121431 Online: https://pubmed.ncbi.nlm.nih.gov/34391377/
2. Review indexed in PubMed (PMID 33164294). *Is it safe to consume traditional medicinal plants during pregnancy?*. Online: https://pubmed.ncbi.nlm.nih.gov/33164294/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
