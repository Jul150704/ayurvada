# Lemon — Lemon

**Scientific name:** Citrus limon
**Taxonomy confidence:** high
**Taxonomy note:** The class label corresponds to Citrus limon.

## Traditional uses reported in the literature
- Common cold and sore-throat related traditional use
- Fever
- Scurvy prevention/treatment historically through vitamin-C-rich citrus use
- Rheumatism and pain-related folk use

## Traditional treatment context
Fruit juice/peel/essential oil have distinct traditional and modern uses.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Citrus essential oils and some raw materials can be phototoxic on skin; concentrated oil is not equivalent to food use.

## References
1. Klimek-Szczykutowicz M, Szopa A, Ekiert H. Plants. 2020;9(1):119. *Citrus limon (Lemon) Phenomenon—A Review of the Chemistry, Pharmacological Properties, Applications in the Modern Pharmaceutical, Food, and Cosmetics Industries, and Biotechnological Studies*. DOI: https://doi.org/10.3390/plants9010119 Online: https://pubmed.ncbi.nlm.nih.gov/31963590/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
