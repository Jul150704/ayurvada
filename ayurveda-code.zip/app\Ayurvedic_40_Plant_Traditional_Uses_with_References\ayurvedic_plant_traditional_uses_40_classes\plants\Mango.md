# Mango — Mango

**Scientific name:** Mangifera indica
**Taxonomy confidence:** high
**Taxonomy note:** The class label corresponds to Mangifera indica.

## Traditional uses reported in the literature
- Diarrhea and dysentery
- Fever
- Traditional diabetes-related use
- Inflammatory complaints
- Parasitic/infectious complaints in some ethnomedicinal traditions

## Traditional treatment context
Leaves, bark, fruit, peel, seed and other parts have distinct traditional applications.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Evidence differs greatly by plant part and preparation. Mango extracts should not replace treatment for diabetes, infection or inflammatory disease.

## References
1. Ediriweera MK, Tennekoon KH, Samarakoon SR. Evidence-Based Complementary and Alternative Medicine. 2017:6949835. *A Review on Ethnopharmacological Applications, Pharmacological Activities, and Bioactive Compounds of Mangifera indica (Mango)*. DOI: https://doi.org/10.1155/2017/6949835 Online: https://pubmed.ncbi.nlm.nih.gov/29456572/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
