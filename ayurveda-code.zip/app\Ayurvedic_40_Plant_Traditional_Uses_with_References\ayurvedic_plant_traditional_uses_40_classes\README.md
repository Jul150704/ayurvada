# 40-class medicinal-plant traditional-use research package

Generated for the 40 ImageFolder class labels in the Ayurveda plant-classification project.

## Contents
- `plant_information.json` — master machine-readable dataset for app integration.
- `plant_information.csv` — flat table for review/editing.
- `ALL_40_PLANTS.md` — human-readable summary of every class.
- `plants/` — one Markdown file per class label, named exactly like the classifier class.
- `REFERENCES.md` — de-duplicated bibliography with online paper links/DOIs.
- `TAXONOMY_WARNINGS.md` — labels that are ambiguous or only probable species mappings.
- `integration_example.py` — minimal Python lookup example.

## Intended wording in your application
Prefer **“Traditional uses reported in the literature”** or **“Traditionally used for…”** rather than **“Treats…”**. The model predicts an image class; it does not diagnose disease or confirm a plant is safe to consume.

## Safety / academic integrity
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.

The bibliography is designed to let you verify each statement against the linked paper before putting it into the final FYP report or deployed application.
