# Jasmine — Jasmine

**Scientific name:** Jasminum spp. (representative source: Jasminum sambac)
**Taxonomy confidence:** ambiguous
**Taxonomy note:** The class label does not identify a species. The cited paper is for Jasminum sambac and should be treated as representative, not a confirmed species mapping.

## Traditional uses reported in the literature
- Insomnia and headache in J. sambac traditional use
- Dental complaints
- Bruises
- Diarrhea and abdominal pain
- Dizziness and difficult-labor related traditional use

## Traditional treatment context
Uses are species- and region-specific. The app should display a taxonomy-warning badge for this class.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Do not transfer the cited J. sambac uses to all jasmine species. Pregnancy/labor-related claims are especially unsuitable for self-treatment.

## References
1. Wang H, et al. Journal of Ethnopharmacology. 2026;354:120478. *Jasminum sambac: Progress in research on ethnopharmacology, phytochemistry, pharmacological actions and other applications*. DOI: https://doi.org/10.1016/j.jep.2025.120478 Online: https://pubmed.ncbi.nlm.nih.gov/40882791/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
