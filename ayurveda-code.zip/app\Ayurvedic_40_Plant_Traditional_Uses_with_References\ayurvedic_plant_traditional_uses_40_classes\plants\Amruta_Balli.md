# Amruta_Balli — Amruta Balli / Guduchi

**Scientific name:** Tinospora cordifolia
**Taxonomy confidence:** high
**Taxonomy note:** Amruta/Amrita Balli and Guduchi commonly refer to Tinospora cordifolia in Indian traditional medicine.

## Traditional uses reported in the literature
- Fever
- Jaundice and liver-related traditional use
- Diabetes
- Urinary complaints
- Dysentery, skin complaints and helminth-related traditional use

## Traditional treatment context
Stems and other parts appear in Ayurvedic preparations; this package deliberately omits preparation ratios and doses.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Do not assume “natural” means risk-free. Tinospora products can interact with medicines and should not be used to replace treatment for diabetes, liver disease or infection.

## References
1. Chaudhary A, et al. Heliyon. 2024;10(10):e31229. *Indian herb Tinospora cordifolia and Tinospora species: Phytochemical and therapeutic application*. DOI: https://doi.org/10.1016/j.heliyon.2024.e31229 Online: https://pubmed.ncbi.nlm.nih.gov/38813196/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
