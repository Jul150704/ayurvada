/* ============================================================
   The living library — catalogue, search, filters, discovery
   ============================================================ */

import { prefersReducedMotion, revealChildren } from "./motion.js";
import { toast } from "./ui.js";
import { noteDiscovery } from "./garden.js";

let catalogue = [];
let activeThemes = new Set();
let query = "";
let onSelect = () => {};

export function getCatalogue() {
  return catalogue;
}

export function findPlant(label) {
  return catalogue.find((p) => p.class_label === label) || null;
}

export async function initLibrary(selectHandler) {
  onSelect = selectHandler;

  try {
    const response = await fetch("/api/plants");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();
    catalogue = Array.isArray(data.plants) ? data.plants : [];
  } catch (error) {
    console.error("Could not load the plant catalogue", error);

    const rail = document.getElementById("rail");
    if (rail) {
      rail.textContent = "";
      rail.appendChild(
        emptyState("The library could not be opened just now. Please refresh the page.")
      );
    }
    return;
  }

  buildFilters();
  wireSearch();
  wireRailNav();
  wireDiscovery();
  renderRail();
  scheduleDailyFact();
}

/* ---- Filters ----------------------------------------------- */

function buildFilters() {
  const wrap = document.getElementById("filters");
  if (!wrap) return;

  const counts = new Map();
  catalogue.forEach((plant) => {
    (plant.themes || []).forEach((theme) => {
      counts.set(theme, (counts.get(theme) || 0) + 1);
    });
  });

  const themes = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);

  wrap.textContent = "";

  themes.forEach(([theme, count]) => {
    const chip = document.createElement("button");
    chip.className = "chip";
    chip.type = "button";
    chip.setAttribute("aria-pressed", "false");
    chip.textContent = `${theme} · ${count}`;

    chip.addEventListener("click", () => {
      if (activeThemes.has(theme)) {
        activeThemes.delete(theme);
        chip.setAttribute("aria-pressed", "false");
      } else {
        activeThemes.add(theme);
        chip.setAttribute("aria-pressed", "true");
      }
      renderRail();
    });

    wrap.appendChild(chip);
  });
}

/* ---- Search ------------------------------------------------ */

function wireSearch() {
  const input = document.getElementById("searchInput");
  if (!input) return;

  let timer;

  input.addEventListener("input", () => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => {
      query = input.value.trim().toLowerCase();
      renderRail();
    }, 140);
  });
}

function matches(plant) {
  if (activeThemes.size) {
    const themes = plant.themes || [];
    const hit = Array.from(activeThemes).every((t) => themes.includes(t));
    if (!hit) return false;
  }

  if (!query) return true;

  const haystack = [
    plant.display_name,
    plant.scientific_name,
    plant.class_label.replace(/_/g, " "),
    plant.sanskrit_name ? plant.sanskrit_name.iast : "",
    plant.sanskrit_name ? plant.sanskrit_name.devanagari : "",
    (plant.uses || []).join(" "),
    (plant.themes || []).join(" "),
  ]
    .join(" ")
    .toLowerCase();

  return haystack.includes(query);
}

/* ---- Rail -------------------------------------------------- */

function renderRail() {
  const rail = document.getElementById("rail");
  if (!rail) return;

  const results = catalogue.filter(matches);

  rail.textContent = "";

  if (!results.length) {
    rail.appendChild(
      emptyState("No plant in the catalogue matches that. Try a broader term.")
    );
    return;
  }

  results.forEach((plant) => rail.appendChild(plantCard(plant)));
  revealChildren(rail);
}

function emptyState(message) {
  const el = document.createElement("div");
  el.className = "empty";

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "empty__glyph");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", "#i-leaf");
  svg.appendChild(use);

  const p = document.createElement("p");
  p.textContent = message;

  el.append(svg, p);
  return el;
}

function plantCard(plant) {
  const card = document.createElement("button");
  card.className = "plant-card";
  card.type = "button";
  card.setAttribute("role", "listitem");
  card.setAttribute(
    "aria-label",
    `${plant.display_name}. ${plant.summary || "Open this entry."}`
  );

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "plant-card__glyph");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", "#i-leaf");
  svg.appendChild(use);
  card.appendChild(svg);

  const deva = document.createElement("p");
  deva.className = "plant-card__deva deva";
  deva.textContent = plant.sanskrit_name ? plant.sanskrit_name.devanagari : "";
  card.appendChild(deva);

  if (plant.sanskrit_name) {
    const iast = document.createElement("p");
    iast.className = "plant-card__iast";
    iast.textContent = plant.sanskrit_name.iast;
    card.appendChild(iast);
  }

  const name = document.createElement("p");
  name.className = "plant-card__name";
  name.textContent = plant.display_name;

  const sci = document.createElement("p");
  sci.className = "plant-card__sci";
  sci.textContent = plant.scientific_name;

  const benefit = document.createElement("p");
  benefit.className = "plant-card__benefit";
  benefit.textContent = plant.summary;

  const refs = document.createElement("span");
  refs.className = "plant-card__refs";
  refs.textContent = `${plant.reference_count} ref${plant.reference_count === 1 ? "" : "s"}`;

  card.append(name, sci, benefit, refs);

  card.addEventListener("click", () => onSelect(plant.class_label));

  addTilt(card);
  return card;
}

/* Cards lean toward the cursor — disabled entirely under reduced motion. */
function addTilt(card) {
  if (prefersReducedMotion()) return;

  card.addEventListener("mousemove", (e) => {
    const r = card.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;

    card.style.setProperty(
      "transform",
      `perspective(760px) rotateX(${(-py * 7).toFixed(2)}deg) rotateY(${(px * 9).toFixed(2)}deg) translateY(-5px)`
    );
  });

  const reset = () => card.style.removeProperty("transform");
  card.addEventListener("mouseleave", reset);
  card.addEventListener("blur", reset);
}

function wireRailNav() {
  const rail = document.getElementById("rail");
  const prev = document.getElementById("railPrev");
  const next = document.getElementById("railNext");
  if (!rail || !prev || !next) return;

  const step = () => Math.max(240, rail.clientWidth * 0.7);
  const behavior = prefersReducedMotion() ? "auto" : "smooth";

  prev.addEventListener("click", () => rail.scrollBy({ left: -step(), behavior }));
  next.addEventListener("click", () => rail.scrollBy({ left: step(), behavior }));
}

/* ---- Discovery --------------------------------------------- */

function wireDiscovery() {
  const btn = document.getElementById("surpriseBtn");
  if (!btn) return;

  btn.addEventListener("click", () => {
    if (!catalogue.length) return;

    const plant = catalogue[Math.floor(Math.random() * catalogue.length)];

    noteDiscovery();
    onSelect(plant.class_label);

    toast({
      title: "The garden offers",
      text: `${plant.display_name} — ${plant.summary || "an entry worth reading."}`,
      icon: "#i-sparkle",
    });
  });
}

/* One quiet fact per day, chosen deterministically from the date. */
function scheduleDailyFact() {
  if (!catalogue.length) return;

  const today = new Date().toISOString().slice(0, 10);

  try {
    if (localStorage.getItem("ayurvana:fact") === today) return;
    localStorage.setItem("ayurvana:fact", today);
  } catch (e) {
    /* Without storage the fact may repeat — harmless. */
  }

  const seed = today.split("-").reduce((a, part) => a + Number(part), 0);
  const plant = catalogue[seed % catalogue.length];

  window.setTimeout(() => {
    toast({
      title: "Today in the garden",
      text: `${plant.display_name} (${plant.scientific_name}) — ${plant.summary}`,
      icon: "#i-flower",
      duration: 11000,
    });
  }, 3400);
}
