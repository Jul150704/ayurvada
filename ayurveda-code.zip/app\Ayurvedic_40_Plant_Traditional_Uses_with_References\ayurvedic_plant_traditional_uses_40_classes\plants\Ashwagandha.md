# Ashwagandha — Ashwagandha

**Scientific name:** Withania somnifera
**Taxonomy confidence:** high
**Taxonomy note:** The class label is unambiguous for Withania somnifera.

## Traditional uses reported in the literature
- Rasayana/rejuvenative use for strength and nourishment
- Stress and anxiety-related traditional use
- Sleep and nervous-system support
- Male sexual/reproductive vitality in traditional texts

## Traditional treatment context
Traditionally used in powders/extracts/formulations; this dataset does not provide dosage instructions.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
May interact with sedatives, thyroid, glucose, blood-pressure or immune-modulating medicines. Pregnancy use requires professional advice.

## References
1. Mukherjee PK, et al. Journal of Ethnopharmacology. 2021;264:113157. *Withania somnifera (L.) Dunal - Modern perspectives of an ancient Rasayana from Ayurveda*. DOI: https://doi.org/10.1016/j.jep.2020.113157 Online: https://pubmed.ncbi.nlm.nih.gov/32783987/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
