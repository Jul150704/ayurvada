# Aloevera — Aloe vera

**Scientific name:** Aloe vera
**Taxonomy confidence:** high
**Taxonomy note:** The dataset label closely corresponds to Aloe vera.

## Traditional uses reported in the literature
- Topical use for minor burns and irritated skin
- Traditional wound/skin care
- Aloe latex has historically been used as a laxative for constipation

## Traditional treatment context
Traditional reports distinguish inner gel/topical use from latex. No dose or self-treatment instructions are provided here.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Oral aloe latex can cause significant adverse effects and is not equivalent to topical aloe gel. Pregnancy and medication interactions require professional review.

## References
1. Surjushe A, Vasani R, Saple DG. Indian Journal of Dermatology. 2008;53(4):163-166. *Aloe vera: a short review*. DOI: https://doi.org/10.4103/0019-5154.44785 Online: https://pmc.ncbi.nlm.nih.gov/articles/PMC2763764/
2. Review indexed in PubMed (PMID 33164294). *Is it safe to consume traditional medicinal plants during pregnancy?*. Online: https://pubmed.ncbi.nlm.nih.gov/33164294/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
