# Amla — Amla / Indian gooseberry

**Scientific name:** Phyllanthus emblica (syn. Emblica officinalis)
**Taxonomy confidence:** high
**Taxonomy note:** Amla is a well-established common name for Phyllanthus emblica.

## Traditional uses reported in the literature
- Common cold, cough and fever
- Digestive complaints such as dyspepsia, colic, flatulence and hyperacidity
- Diarrhea/dysentery and other gastrointestinal complaints
- Ayurvedic rejuvenative/nutritional use

## Traditional treatment context
The fruit is the part most commonly discussed in the cited review; traditional systems use it alone and in compound formulations.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Clinical evidence varies by indication. It can affect glucose or other physiological parameters, so medication users should seek professional advice.

## References
1. Saini R, et al. Journal of Ethnopharmacology. 2022;282:114570. *Traditional uses, bioactive composition, pharmacology, and toxicology of Phyllanthus emblica fruits: A comprehensive review*. DOI: https://doi.org/10.1016/j.jep.2021.114570 Online: https://pubmed.ncbi.nlm.nih.gov/34480995/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
