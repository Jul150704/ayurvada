# Geranium — Geranium

**Scientific name:** Geranium spp. / Pelargonium spp. (dataset species unspecified)
**Taxonomy confidence:** ambiguous
**Taxonomy note:** The label “Geranium” does not encode a species and common usage can also refer to Pelargonium. The citation is genus-level Geranium literature.

## Traditional uses reported in the literature
- Wound/skin-related ethnomedicinal use
- Pain and inflammation-related use
- Gastrointestinal complaints
- Respiratory complaints in various traditional systems

## Traditional treatment context
Use varies greatly by Geranium/Pelargonium species. This entry is intentionally genus-level.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Do not transfer a medicinal claim from one Geranium/Pelargonium species to another without botanical verification.

## References
1. Alshehri B. Saudi Journal of Biological Sciences. 2024;31(4):103940. *The geranium genus: A comprehensive study on ethnomedicinal uses, phytochemical compounds, and pharmacological importance*. DOI: https://doi.org/10.1016/j.sjbs.2024.103940 Online: https://pubmed.ncbi.nlm.nih.gov/38371877/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
