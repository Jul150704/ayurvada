"""Full classification metrics on the fixed held-out test split.

Computes accuracy, per-class precision / recall / F1, macro and weighted
averages, confidence calibration, and the most common confusions — for one or
more checkpoints. Results are written to models/metrics.json so the report and
the numbers can never drift apart.

Usage:
  python scripts/metrics.py models/baseline_original.pt models/plant_model.pt
"""
from pathlib import Path
import json
import sys

import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from PIL import Image

DATA = Path("data/images")
SPLIT_FILE = Path("models/split.json")
OUT_FILE = Path("models/metrics.json")

eval_tfm = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])


class TestSet(Dataset):
    def __init__(self, rels, classes):
        self.rels = rels
        self.index = {c: i for i, c in enumerate(classes)}

    def __len__(self):
        return len(self.rels)

    def __getitem__(self, i):
        rel = self.rels[i]
        img = Image.open(DATA / rel).convert("RGB")
        return eval_tfm(img), self.index[rel.split("/")[0]], int(Path(rel).name.startswith("ext_"))


@torch.inference_mode()
def collect(model, loader, device, n_cls):
    """Return confusion matrix plus confidence arrays."""
    cm = torch.zeros(n_cls, n_cls, dtype=torch.long)   # [true][pred]
    conf_correct, conf_wrong = [], []
    src_hits = {0: [0, 0], 1: [0, 0]}

    for x, y, src in loader:
        probs = torch.softmax(model(x.to(device)), dim=1).cpu()
        conf, pred = probs.max(1)

        for t, p, c, s in zip(y.tolist(), pred.tolist(), conf.tolist(), src.tolist()):
            cm[t][p] += 1
            (conf_correct if t == p else conf_wrong).append(c)
            src_hits[s][0] += int(t == p)
            src_hits[s][1] += 1

    return cm, conf_correct, conf_wrong, src_hits


def prf(cm, classes):
    """Per-class precision / recall / F1 from a confusion matrix."""
    rows = {}
    for i, name in enumerate(classes):
        tp = cm[i][i].item()
        fn = cm[i].sum().item() - tp
        fp = cm[:, i].sum().item() - tp

        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0

        rows[name] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": tp + fn,
        }
    return rows


def summarise(rows, cm):
    total = cm.sum().item()
    correct = cm.diag().sum().item()
    supports = {k: v["support"] for k, v in rows.items()}
    n = len(rows)

    macro = {m: sum(v[m] for v in rows.values()) / n for m in ("precision", "recall", "f1")}
    weighted = {
        m: sum(v[m] * supports[k] for k, v in rows.items()) / max(total, 1)
        for m in ("precision", "recall", "f1")
    }
    return {
        "accuracy": correct / max(total, 1),
        "macro": macro,
        "weighted": weighted,
        "n_test": total,
    }


def main():
    paths = sys.argv[1:]
    if not paths:
        sys.exit(__doc__)

    payload = json.loads(SPLIT_FILE.read_text())
    classes, test_rel = payload["classes"], payload["split"]["test"]
    device = "cuda" if torch.cuda.is_available() else "cpu"

    loader = DataLoader(TestSet(test_rel, classes), batch_size=32, num_workers=0)
    print(f"test images {len(test_rel)} · classes {len(classes)} · device {device}\n")

    report = {}

    for path in paths:
        name = Path(path).stem
        ckpt = torch.load(path, map_location=device)

        model = models.resnet18(weights=None)
        model.fc = nn.Linear(model.fc.in_features, len(classes))
        model.load_state_dict(ckpt["state_dict"])
        model.to(device).eval()

        cm, ok_conf, bad_conf, src = collect(model, loader, device, len(classes))
        rows = prf(cm, classes)
        summary = summarise(rows, cm)

        mean = lambda a: (sum(a) / len(a)) if a else float("nan")

        confusions = []
        for i in range(len(classes)):
            for j in range(len(classes)):
                if i != j and cm[i][j] > 0:
                    confusions.append((cm[i][j].item(), classes[i], classes[j]))
        confusions.sort(reverse=True)

        report[name] = {
            "summary": summary,
            "per_class": rows,
            "confidence": {
                "mean_when_correct": mean(ok_conf),
                "mean_when_wrong": mean(bad_conf),
                "n_correct": len(ok_conf),
                "n_wrong": len(bad_conf),
            },
            "by_source": {
                "original": {"accuracy": src[0][0] / max(src[0][1], 1), "n": src[0][1]},
                "merged": {"accuracy": src[1][0] / max(src[1][1], 1), "n": src[1][1]},
            },
            "top_confusions": [
                {"count": c, "true": t, "predicted": p} for c, t, p in confusions[:10]
            ],
        }

        s = summary
        print(f"=== {name} ===")
        print(f"  accuracy          {s['accuracy']*100:6.2f}%")
        print(f"  macro F1          {s['macro']['f1']*100:6.2f}%")
        print(f"  macro precision   {s['macro']['precision']*100:6.2f}%")
        print(f"  macro recall      {s['macro']['recall']*100:6.2f}%")
        print(f"  weighted F1       {s['weighted']['f1']*100:6.2f}%")
        print(f"  mean confidence   {mean(ok_conf)*100:6.2f}% when right · "
              f"{mean(bad_conf)*100:6.2f}% when wrong")
        print(f"  by source         original {report[name]['by_source']['original']['accuracy']*100:.2f}% · "
              f"merged {report[name]['by_source']['merged']['accuracy']*100:.2f}%")

        worst = sorted(rows.items(), key=lambda kv: kv[1]["f1"])[:5]
        print("  lowest F1 classes:")
        for cls, v in worst:
            print(f"    {cls:16s} F1 {v['f1']*100:6.2f}%  (P {v['precision']*100:.1f} / "
                  f"R {v['recall']*100:.1f}, n={v['support']})")
        print("  top confusions:")
        for c in report[name]["top_confusions"][:4]:
            print(f"    {c['true']} -> {c['predicted']}  ({c['count']}x)")
        print()

    OUT_FILE.write_text(json.dumps(report, indent=2))
    print(f"Wrote {OUT_FILE}")


if __name__ == "__main__":
    main()
