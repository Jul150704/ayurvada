# Dataset guide

## Images
Use one folder per plant class:

data/images/
- Ashwagandha/
- Neem/
- Tulsi/
- ...

Keep class names consistent. Remove duplicates and poor-quality images. Record the source/licence of each image if required by your institution.

## Research papers
Place PDFs in `data/research_papers/`.

Recommended metadata to maintain for each source:
- title
- authors
- year
- DOI/URL
- plant/species
- claim supported
- evidence type
- page/section

## Important evidence separation
The application should have separate fields for:
1. Botanical identification
2. Traditional Ayurvedic uses
3. Reported phytochemicals/constituents
4. Modern experimental evidence
5. Human clinical evidence
6. Safety/contraindications
7. Source citation

Do not convert traditional-use claims into medical recommendations.
