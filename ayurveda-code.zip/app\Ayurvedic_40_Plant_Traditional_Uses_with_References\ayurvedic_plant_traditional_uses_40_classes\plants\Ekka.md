# Ekka — Ekka / Giant milkweed

**Scientific name:** Calotropis gigantea (probable)
**Taxonomy confidence:** probable
**Taxonomy note:** The common name “Ekka” can refer to Calotropis species; C. gigantea is a probable mapping, but C. procera can also be called by related vernacular names.

## Traditional uses reported in the literature
- Pain
- Inflammation
- Wounds
- Infections in traditional use

## Traditional treatment context
Traditional use includes latex, leaves, flowers and bark in different systems. This package intentionally gives no preparation instructions.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
HIGH-RISK: Calotropis contains cardiac glycosides/cardenolides and irritating latex. Do not ingest or use as a home treatment; species identity and toxicity are critical.

## References
1. Review indexed in PubMed (PMID 42566010). *From traditional uses to biochemical evidence: phytochemical diversity and bioactivities of Calotropis gigantea—a comprehensive update since 2013*. DOI: https://doi.org/10.1007/s00044-026-03602-w Online: https://pubmed.ncbi.nlm.nih.gov/42566010/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
