/* ============================================================
   The botanical journal — how a plant is presented once found
   ============================================================ */

import { prefersReducedMotion } from "./motion.js";
import { toast, initPopover } from "./ui.js";
import * as Garden from "./garden.js";

/* Plant parts are matched against the sourced use text. A hotspot only
   appears when the literature actually mentions that part — nothing is
   assumed about which part of a plant is used. */
const PARTS = [
  { id: "leaf",   label: "Leaf",   glyph: "#i-leaf",   keys: ["leaf", "leaves", "foliage"] },
  { id: "root",   label: "Root",   glyph: "#i-root",   keys: ["root", "rhizome", "tuber"] },
  { id: "flower", label: "Flower", glyph: "#i-flower", keys: ["flower", "petal", "blossom"] },
  { id: "fruit",  label: "Fruit",  glyph: "#i-sprout", keys: ["fruit", "berry", "pulp"] },
  { id: "seed",   label: "Seed",   glyph: "#i-sprout", keys: ["seed", "kernel", "nut"] },
  { id: "bark",   label: "Bark",   glyph: "#i-root",   keys: ["bark", "stem", "wood"] },
  { id: "resin",  label: "Sap",    glyph: "#i-leaf",   keys: ["latex", "gel", "resin", "sap", "oil", "juice"] },
];

let popover = null;
let current = null;

export function initJournal() {
  popover = initPopover();
  wireTabs();
  wireActions();
}

/* ---- Normalisation ----------------------------------------
   /predict and /api/plants/{label} return slightly different
   shapes; the journal only ever sees one. */

export function normalise(raw) {
  return {
    class_label: raw.class_label || raw.plant || "",
    display_name: raw.display_name || raw.plant || "Unknown plant",
    scientific_name: raw.scientific_name || "",
    sanskrit_name: raw.sanskrit_name || null,
    uses: raw.traditional_uses || raw.traditional_uses_reported || [],
    context: raw.traditional_treatment_context || "",
    evidence: raw.evidence_note || "",
    safety: raw.safety_note || "",
    references: raw.references || [],
    taxonomy_confidence: raw.taxonomy_confidence || "",
    taxonomy_note: raw.taxonomy_note || "",
  };
}

/* ---- Render ------------------------------------------------ */

export function renderJournal(raw, options = {}) {
  const plant = normalise(raw);
  current = plant;

  const journal = document.getElementById("journal");
  if (!journal) return;

  renderHead(plant, options);
  renderUses(plant);
  renderResearch(plant);
  renderPrecautions(plant);
  renderContext(plant);
  renderAnatomy(plant);
  updateSaveButton();

  journal.classList.remove("hidden");

  if (!prefersReducedMotion()) {
    journal.classList.remove("unfurling");
    void journal.offsetWidth; // restart the animation
    journal.classList.add("unfurling");
  }

  selectTab("tab-uses");

  if (options.scroll !== false) {
    journal.scrollIntoView({
      behavior: prefersReducedMotion() ? "auto" : "smooth",
      block: "start",
    });
  }

  journal.focus({ preventScroll: true });
}

function renderHead(plant, options) {
  setText("journalName", plant.display_name);
  setText("journalSci", plant.scientific_name);

  const deva = document.getElementById("journalDeva");
  const iast = document.getElementById("journalIast");

  if (plant.sanskrit_name) {
    deva.textContent = plant.sanskrit_name.devanagari;
    iast.textContent = plant.sanskrit_name.iast;
    deva.classList.remove("hidden");
    iast.classList.remove("hidden");
  } else {
    deva.classList.add("hidden");
    iast.classList.add("hidden");
  }

  // The uploaded photograph becomes the specimen in the crest.
  const img = document.getElementById("journalImage");
  if (img) {
    if (options.image) {
      img.src = options.image;
      img.alt = `The photograph you uploaded, identified as ${plant.display_name}`;
      img.hidden = false;
    } else {
      img.removeAttribute("src");
      img.alt = "";
      img.hidden = true;
    }
  }

  // Confidence only means something for an actual prediction.
  const pill = document.getElementById("confidence");
  const low = document.getElementById("lowConfidence");

  if (typeof options.confidence === "number") {
    const value = options.confidence;
    pill.classList.remove("hidden");
    pill.dataset.level = value < 60 ? "low" : "high";
    setText("confidenceText", `${value.toFixed(1)}% confidence`);
    low.classList.toggle("hidden", value >= 60);
  } else {
    pill.classList.add("hidden");
    low.classList.add("hidden");
  }

  const badge = document.getElementById("taxonomyBadge");
  if (plant.taxonomy_confidence) {
    badge.textContent = `Taxonomy: ${plant.taxonomy_confidence}`;
    badge.classList.remove("hidden");
  } else {
    badge.classList.add("hidden");
  }
}

function renderUses(plant) {
  const body = document.getElementById("usesBody");
  body.textContent = "";

  setText("countUses", plant.uses.length ? String(plant.uses.length) : "");

  if (!plant.uses.length) {
    body.appendChild(
      note("No traditional-use information has been recorded for this plant yet.")
    );
    return;
  }

  const intro = document.createElement("p");
  intro.className = "muted";
  intro.textContent =
    "Uses reported in the cited literature. These are historical and ethnomedicinal reports, not clinical recommendations.";
  body.appendChild(intro);

  const list = document.createElement("ul");
  list.className = "leaf-list";

  plant.uses.forEach((use) => {
    const li = document.createElement("li");
    li.textContent = use;
    list.appendChild(li);
  });

  body.appendChild(list);
}

function renderResearch(plant) {
  const body = document.getElementById("researchBody");
  body.textContent = "";

  setText("countRefs", plant.references.length ? String(plant.references.length) : "");

  if (!plant.references.length) {
    body.appendChild(note("No research references are recorded for this plant."));
    return;
  }

  plant.references.forEach((reference) => {
    const card = document.createElement("article");
    card.className = "ref";

    const title = document.createElement("h4");
    title.className = "ref__title";
    title.textContent = reference.title || "Research source";
    card.appendChild(title);

    if (reference.citation) {
      const cite = document.createElement("p");
      cite.className = "ref__citation";
      cite.textContent = reference.citation;
      card.appendChild(cite);
    }

    const meta = document.createElement("div");
    meta.className = "ref__meta";

    if (reference.year) {
      const year = document.createElement("span");
      year.textContent = String(reference.year);
      meta.appendChild(year);
    }

    if (reference.doi) {
      const doi = document.createElement("span");
      doi.className = "ref__doi";
      doi.textContent = reference.doi;
      meta.appendChild(doi);
    }

    if (reference.url) {
      const link = document.createElement("a");
      link.href = reference.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "Read the paper";
      meta.appendChild(link);
    }

    card.appendChild(meta);
    body.appendChild(card);
  });
}

function renderPrecautions(plant) {
  const body = document.getElementById("precautionsBody");
  body.textContent = "";

  const banner = document.createElement("div");
  banner.className = "caution";

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", "#i-alert");
  svg.appendChild(use);

  const p = document.createElement("p");
  p.textContent =
    "This catalogue carries no dosage and no preparation instructions by design. A misidentified plant combined with a preparation method is exactly how harm happens. Speak to a qualified practitioner before using any plant medicinally.";

  banner.append(svg, p);
  body.appendChild(banner);

  if (plant.safety) {
    const heading = document.createElement("h3");
    heading.textContent = "Recorded for this plant";

    const text = document.createElement("p");
    text.className = "muted";
    text.textContent = plant.safety;

    body.append(heading, text);
  } else {
    body.appendChild(
      note("No plant-specific safety note has been recorded. Absence of a warning is not evidence of safety.")
    );
  }
}

function renderContext(plant) {
  const body = document.getElementById("contextBody");
  body.textContent = "";

  const blocks = [
    ["Traditional treatment context", plant.context],
    ["On the strength of the evidence", plant.evidence],
    ["Identification note", plant.taxonomy_note],
  ];

  let rendered = 0;

  blocks.forEach(([heading, text]) => {
    if (!text) return;
    rendered += 1;

    const h = document.createElement("h3");
    h.textContent = heading;

    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = text;

    body.append(h, p);
  });

  if (!rendered) {
    body.appendChild(note("No additional context has been recorded for this plant."));
  }
}

/* ---- Anatomy hotspots -------------------------------------- */

function renderAnatomy(plant) {
  const wrap = document.getElementById("anatomy");
  wrap.textContent = "";

  const corpus = plant.uses.concat(plant.context ? [plant.context] : []);

  PARTS.forEach((part) => {
    const hits = corpus.filter((line) => {
      const lower = line.toLowerCase();
      return part.keys.some((key) => lower.includes(key));
    });

    if (!hits.length) return;

    const btn = document.createElement("button");
    btn.className = "hotspot";
    btn.type = "button";
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute(
      "aria-label",
      `${part.label}: ${hits.length} reported use${hits.length === 1 ? "" : "s"}`
    );

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("aria-hidden", "true");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", part.glyph);
    svg.appendChild(use);

    const label = document.createElement("span");
    label.textContent = part.label;

    btn.append(svg, label);

    btn.addEventListener("click", () => {
      popover.open(btn, { title: `${part.label} — reported uses`, text: hits });
    });

    wrap.appendChild(btn);
  });

  if (!wrap.children.length) return;

  const hint = document.createElement("p");
  hint.className = "faint";
  hint.textContent = "Plant parts mentioned in the sources — select one.";
  wrap.insertBefore(hint, wrap.firstChild);
}

/* ---- Tabs -------------------------------------------------- */

function wireTabs() {
  const tabs = Array.from(document.querySelectorAll(".tab"));

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => selectTab(tab.id));

    tab.addEventListener("keydown", (e) => {
      const i = tabs.indexOf(tab);
      let target = null;

      if (e.key === "ArrowRight") target = tabs[(i + 1) % tabs.length];
      if (e.key === "ArrowLeft") target = tabs[(i - 1 + tabs.length) % tabs.length];
      if (e.key === "Home") target = tabs[0];
      if (e.key === "End") target = tabs[tabs.length - 1];

      if (!target) return;
      e.preventDefault();
      selectTab(target.id);
      target.focus();
    });
  });
}

function selectTab(id) {
  document.querySelectorAll(".tab").forEach((tab) => {
    const selected = tab.id === id;

    tab.setAttribute("aria-selected", String(selected));
    tab.setAttribute("tabindex", selected ? "0" : "-1");

    const panel = document.getElementById(tab.getAttribute("aria-controls"));
    if (panel) panel.classList.toggle("hidden", !selected);
  });

  if (id === "tab-research" && current && current.class_label) {
    Garden.noteResearchOpened(current.class_label);
  }
}

/* ---- Actions ----------------------------------------------- */

function wireActions() {
  const save = document.getElementById("saveBtn");
  const print = document.getElementById("printBtn");
  const share = document.getElementById("shareBtn");

  if (save) {
    save.addEventListener("click", () => {
      if (!current) return;

      if (Garden.has(current.class_label)) {
        Garden.removePlant(current.class_label);
        toast({ text: `${current.display_name} removed from your garden.`, icon: "#i-leaf" });
      } else {
        Garden.savePlant(current);
        toast({
          title: "Planted",
          text: `${current.display_name} now grows in your garden.`,
          icon: "#i-sprout",
        });
      }

      updateSaveButton();
    });
  }

  if (print) print.addEventListener("click", () => window.print());

  if (share) {
    share.addEventListener("click", async () => {
      if (!current) return;

      const url = `${location.origin}/#plant=${encodeURIComponent(current.class_label)}`;
      const payload = {
        title: `${current.display_name} · AyurVana`,
        text: `${current.display_name} (${current.scientific_name}) in the AyurVana botanical garden`,
        url,
      };

      try {
        if (navigator.share) {
          await navigator.share(payload);
          return;
        }
        await navigator.clipboard.writeText(url);
        toast({ text: "Link copied to your clipboard.", icon: "#i-share" });
      } catch (e) {
        // A cancelled share dialog lands here too — say nothing.
      }
    });
  }

  document.addEventListener("garden:changed", updateSaveButton);
}

function updateSaveButton() {
  const label = document.getElementById("saveBtnText");
  if (!label || !current) return;

  label.textContent = Garden.has(current.class_label)
    ? "Remove from my garden"
    : "Save to my garden";
}

/* ---- Helpers ----------------------------------------------- */

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function note(message) {
  const p = document.createElement("p");
  p.className = "muted";
  p.textContent = message;
  return p;
}
