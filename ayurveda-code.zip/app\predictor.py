from pathlib import Path

import torch
from torch import nn
from torchvision import models, transforms
from PIL import Image

from app.plant_info import get_plant_information


# --------------------------------------------------
# Paths and device
# --------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = PROJECT_ROOT / "models" / "plant_model.pt"

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)


# --------------------------------------------------
# Image preprocessing
# --------------------------------------------------

predict_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])


# --------------------------------------------------
# Load trained model
# --------------------------------------------------

def load_model():

    if not MODEL_PATH.exists():
        return None, None

    checkpoint = torch.load(
        MODEL_PATH,
        map_location=DEVICE
    )

    classes = checkpoint["classes"]

    model = models.resnet18(weights=None)

    model.fc = nn.Linear(
        model.fc.in_features,
        len(classes)
    )

    model.load_state_dict(
        checkpoint["state_dict"]
    )

    model.to(DEVICE)
    model.eval()

    return model, classes


model, classes = load_model()


# --------------------------------------------------
# Predict plant
# --------------------------------------------------

def predict_plant(image: Image.Image):

    if model is None or classes is None:
        return {
            "status": "model_not_trained",
            "plant": "Model not available",
            "confidence": 0,
            "message": "The trained plant model could not be found.",
            "traditional_uses": [],
            "references": []
        }

    # Convert uploaded image to RGB
    image = image.convert("RGB")

    # Preprocess
    input_tensor = predict_transform(image)
    input_tensor = input_tensor.unsqueeze(0).to(DEVICE)

    # Prediction
    with torch.inference_mode():

        outputs = model(input_tensor)

        probabilities = torch.softmax(
            outputs,
            dim=1
        )

        confidence, predicted_index = torch.max(
            probabilities,
            dim=1
        )

    predicted_index = predicted_index.item()
    confidence = confidence.item() * 100

    plant_name = classes[predicted_index]

    # --------------------------------------------------
    # Retrieve traditional plant information
    # --------------------------------------------------

    plant_info = get_plant_information(
        plant_name
    )

    result = {
        "status": "success",
        "plant": plant_name,
        "confidence": round(confidence, 2),
        "message": (
            f"The model predicts that the uploaded image is "
            f"{plant_name} with {confidence:.2f}% confidence."
        )
    }

    if plant_info:

        result["display_name"] = plant_info.get(
            "display_name",
            plant_name
        )

        result["scientific_name"] = plant_info.get(
            "scientific_name",
            ""
        )

        result["taxonomy_confidence"] = plant_info.get(
            "taxonomy_confidence",
            ""
        )

        result["taxonomy_note"] = plant_info.get(
            "taxonomy_note",
            ""
        )

        result["traditional_uses"] = plant_info.get(
            "traditional_uses_reported",
            []
        )

        result["traditional_treatment_context"] = plant_info.get(
            "traditional_treatment_context",
            ""
        )

        result["evidence_note"] = plant_info.get(
            "evidence_note",
            ""
        )

        result["safety_note"] = plant_info.get(
            "safety_note",
            ""
        )

        result["references"] = plant_info.get(
            "references",
            []
        )

        result["sanskrit_name"] = plant_info.get(
            "sanskrit_name"
        )

    else:

        result["display_name"] = plant_name
        result["scientific_name"] = ""
        result["taxonomy_confidence"] = ""
        result["taxonomy_note"] = ""
        result["traditional_uses"] = []
        result["traditional_treatment_context"] = ""
        result["evidence_note"] = ""
        result["safety_note"] = ""
        result["references"] = []
        result["sanskrit_name"] = None

    return result