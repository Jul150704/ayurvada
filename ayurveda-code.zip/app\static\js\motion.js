/* ============================================================
   Motion system
   Scroll reveals, hero parallax, firefly field, theme switching.
   Every effect checks prefersReducedMotion() and degrades to a
   calm, static state rather than simply vanishing.
   ============================================================ */

const reduceQuery = window.matchMedia("(prefers-reduced-motion: reduce)");

export function prefersReducedMotion() {
  return reduceQuery.matches;
}

/* ---- Scroll reveal ---------------------------------------- */

export function initReveal() {
  const targets = document.querySelectorAll(".reveal");

  if (!("IntersectionObserver" in window)) {
    targets.forEach((el) => el.classList.add("is-visible"));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    },
    { rootMargin: "0px 0px -12% 0px", threshold: 0.08 }
  );

  targets.forEach((el) => observer.observe(el));
}

/* Reveal newly injected nodes (library cards, garden beds) */
export function revealChildren(container, stagger = true) {
  const items = Array.from(container.children);

  items.forEach((el, i) => {
    el.classList.add("reveal");
    if (stagger) el.style.setProperty("--i", String(Math.min(i, 12)));
  });

  // Next frame, so the initial hidden state is actually painted first.
  requestAnimationFrame(() => {
    items.forEach((el) => el.classList.add("is-visible"));
  });
}

/* ---- Hero parallax ---------------------------------------- */

export function initParallax() {
  const layers = Array.from(document.querySelectorAll(".hero__layer"));
  if (!layers.length) return;

  let ticking = false;

  const apply = () => {
    const y = window.scrollY;

    layers.forEach((layer) => {
      const depth = parseFloat(layer.dataset.depth || "0.2");
      layer.style.setProperty("--shift", `${y * depth}px`);
    });

    ticking = false;
  };

  const onScroll = () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(apply);
  };

  const enable = () => {
    if (prefersReducedMotion()) {
      layers.forEach((l) => l.style.setProperty("--shift", "0px"));
      window.removeEventListener("scroll", onScroll);
      return;
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    apply();
  };

  enable();
  reduceQuery.addEventListener("change", enable);
}

/* ---- Fireflies (Moonlight Garden only) --------------------- */

const FIREFLY_COUNT = 16;

export function initFireflies() {
  const field = document.getElementById("fireflies");
  if (!field) return;

  const render = () => {
    field.textContent = "";

    if (prefersReducedMotion() || !isMoonlight()) return;

    for (let i = 0; i < FIREFLY_COUNT; i += 1) {
      const fly = document.createElement("span");
      fly.className = "firefly";

      fly.style.setProperty("left", `${Math.random() * 100}%`);
      fly.style.setProperty("top", `${40 + Math.random() * 60}%`);
      fly.style.setProperty("--dx", `${(Math.random() - 0.5) * 190}px`);
      fly.style.setProperty("--dy", `${-90 - Math.random() * 200}px`);
      fly.style.setProperty("--dur", `${15 + Math.random() * 13}s`);
      fly.style.setProperty("--delay", `${-Math.random() * 22}s`);

      field.appendChild(fly);
    }
  };

  render();
  reduceQuery.addEventListener("change", render);

  return render;
}

/* ---- Theme ------------------------------------------------- */

export function isMoonlight() {
  const attr = document.documentElement.getAttribute("data-theme");
  if (attr === "moonlight") return true;
  if (attr === "garden") return false;
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}

export function initTheme(onChange) {
  const toggle = document.getElementById("themeToggle");
  if (!toggle) return;

  const paint = () => {
    const moon = isMoonlight();
    const icon = toggle.querySelector("use");

    if (icon) icon.setAttribute("href", moon ? "#i-sun" : "#i-moon");

    toggle.setAttribute(
      "aria-label",
      moon ? "Return to the daylight garden" : "Switch to the Moonlight Garden"
    );

    if (typeof onChange === "function") onChange(moon);
  };

  toggle.addEventListener("click", () => {
    const next = isMoonlight() ? "garden" : "moonlight";

    document.documentElement.setAttribute("data-theme", next);

    try {
      localStorage.setItem("ayurvana:theme", next);
    } catch (e) {
      /* Storage unavailable — the choice simply won't persist. */
    }

    paint();
  });

  paint();
}
