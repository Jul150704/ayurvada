# Neem — Neem

**Scientific name:** Azadirachta indica
**Taxonomy confidence:** high
**Taxonomy note:** The class label is unambiguous for Azadirachta indica.

## Traditional uses reported in the literature
- Skin conditions and wound-related traditional use
- Oral/dental hygiene traditions
- Fever/infectious-disease related traditional use
- Inflammation-related traditional use

## Traditional treatment context
Leaves, bark, twigs, seed oil and other parts have different traditional uses and risk profiles.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Neem products are not interchangeable; ingestion of concentrated seed oil can be hazardous. Do not use for serious infection or chronic disease without medical guidance.

## References
1. Kumar VS, Navaratnam V. Asian Pacific Journal of Tropical Biomedicine. 2013;3(7):505-514. *Neem (Azadirachta indica): prehistory to contemporary medicinal uses to humankind*. DOI: https://doi.org/10.1016/S2221-1691(13)60105-7 Online: https://pubmed.ncbi.nlm.nih.gov/23835719/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
