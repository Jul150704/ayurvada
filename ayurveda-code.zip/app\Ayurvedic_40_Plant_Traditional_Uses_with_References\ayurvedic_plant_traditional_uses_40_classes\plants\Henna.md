# Henna — Henna

**Scientific name:** Lawsonia inermis
**Taxonomy confidence:** high
**Taxonomy note:** Henna corresponds to Lawsonia inermis.

## Traditional uses reported in the literature
- Topical protection/treatment for fungal skin problems in traditional use
- Lice and dandruff
- Ulcers and wound-related use
- Traditional liver and digestive complaints

## Traditional treatment context
Traditional use is largely topical for dyeing and skin/hair care, with additional internal uses reported historically.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Adverse skin reactions occur; “black henna” may contain para-phenylenediamine (PPD) and is not equivalent to pure henna. G6PD deficiency is a special safety concern.

## References
1. Semwal RB, et al. Journal of Ethnopharmacology. 2014;155(1):80-103. *Lawsonia inermis L. (henna): ethnobotanical, phytochemical and pharmacological aspects*. DOI: https://doi.org/10.1016/j.jep.2014.05.042 Online: https://pubmed.ncbi.nlm.nih.gov/24886774/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
