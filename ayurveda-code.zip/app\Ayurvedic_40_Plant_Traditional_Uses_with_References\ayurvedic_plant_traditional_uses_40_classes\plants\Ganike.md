# Ganike — Ganike / Black nightshade

**Scientific name:** Solanum nigrum
**Taxonomy confidence:** high
**Taxonomy note:** “Ganike” is used for Solanum nigrum in regional Indian plant-name sources.

## Traditional uses reported in the literature
- Sore throat and toothache
- Dermatitis, eczema, boils/carbuncles
- Urinary/urethral complaints
- Traditional use reports also include cancers and kidney-related complaints

## Traditional treatment context
Different plant parts and maturity stages are used in folk traditions; no preparation details are supplied.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Nightshade species and plant maturity matter because glycoalkaloid content varies. Do not use this entry as a cancer or kidney-disease treatment recommendation.

## References
1. Chen X, et al. Frontiers in Pharmacology. 2022;13:918071. *Solanum nigrum Linn.: An Insight into Current Research on Traditional Uses, Phytochemistry, and Pharmacology*. DOI: https://doi.org/10.3389/fphar.2022.918071 Online: https://pubmed.ncbi.nlm.nih.gov/36052142/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
