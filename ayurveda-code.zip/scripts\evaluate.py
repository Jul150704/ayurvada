"""Score one or more checkpoints on the fixed held-out test split.

Reports overall accuracy and, crucially, a breakdown by image source:

  original  images that were in the dataset before the merge
  merged    images added from 'additional dataset.zip' (ext_* files)

The breakdown matters. A model trained on both sources will obviously do
better on merged-source photos it has seen the style of. The honest question
is whether it ALSO improved on the original-source images — that is what
tells you the extra data genuinely helped rather than just widening coverage.

Usage:
  python scripts/evaluate.py models/baseline_original.pt models/plant_model.pt
"""
from pathlib import Path
import json
import sys

import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from PIL import Image

DATA = Path("data/images")
SPLIT_FILE = Path("models/split.json")

eval_tfm = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])


class TestSet(Dataset):
    def __init__(self, rel_paths, classes):
        self.rel = rel_paths
        self.index = {c: i for i, c in enumerate(classes)}

    def __len__(self):
        return len(self.rel)

    def __getitem__(self, i):
        rel = self.rel[i]
        image = Image.open(DATA / rel).convert("RGB")
        label = self.index[rel.split("/")[0]]
        is_merged = int(Path(rel).name.startswith("ext_"))
        return eval_tfm(image), label, is_merged


def load_model(path, classes, device):
    ckpt = torch.load(path, map_location=device)
    if ckpt["classes"] != classes:
        sys.exit(f"{path}: class list differs from split.json — cannot compare fairly.")
    model = models.resnet18(weights=None)
    model.fc = nn.Linear(model.fc.in_features, len(classes))
    model.load_state_dict(ckpt["state_dict"])
    return model.to(device).eval()


@torch.inference_mode()
def score(model, loader, classes, device):
    n_cls = len(classes)
    correct = torch.zeros(n_cls)
    total = torch.zeros(n_cls)
    by_source = {0: [0, 0], 1: [0, 0]}  # source -> [correct, total]

    for x, y, src in loader:
        preds = model(x.to(device)).argmax(1).cpu()
        hit = (preds == y)
        for c, t, s in zip(hit.tolist(), y.tolist(), src.tolist()):
            correct[t] += c
            total[t] += 1
            by_source[s][0] += c
            by_source[s][1] += 1

    overall = 100.0 * correct.sum().item() / max(total.sum().item(), 1)
    per_class = {
        classes[i]: (100.0 * correct[i].item() / total[i].item()) if total[i] else float("nan")
        for i in range(n_cls)
    }
    sources = {
        name: (100.0 * v[0] / v[1] if v[1] else float("nan"), v[1])
        for name, v in (("original", by_source[0]), ("merged", by_source[1]))
    }
    return overall, per_class, sources


def main():
    paths = sys.argv[1:]
    if not paths:
        sys.exit(__doc__)
    if not SPLIT_FILE.exists():
        sys.exit("models/split.json not found — run scripts/train.py first.")

    payload = json.loads(SPLIT_FILE.read_text())
    classes, test_rel = payload["classes"], payload["split"]["test"]

    device = "cuda" if torch.cuda.is_available() else "cpu"
    loader = DataLoader(TestSet(test_rel, classes), batch_size=32, num_workers=0)
    print(f"test images: {len(test_rel)} · classes: {len(classes)} · device: {device}\n")

    results = {}
    for p in paths:
        name = Path(p).stem
        overall, per_class, sources = score(load_model(p, classes, device), loader, classes, device)
        results[name] = (overall, per_class, sources)

        print(f"=== {name} ===")
        print(f"  overall          {overall:6.2f}%")
        for src, (acc, n) in sources.items():
            print(f"  {src:<16} {acc:6.2f}%   ({n} images)")
        print()

    if len(results) == 2:
        (a_name, (a_ov, a_pc, a_src)), (b_name, (b_ov, b_pc, b_src)) = results.items()
        print(f"=== {b_name} vs {a_name} ===")
        print(f"  overall   {a_ov:6.2f}%  ->  {b_ov:6.2f}%   ({b_ov - a_ov:+.2f} pts)")
        for src in ("original", "merged"):
            print(f"  {src:<9} {a_src[src][0]:6.2f}%  ->  {b_src[src][0]:6.2f}%   "
                  f"({b_src[src][0] - a_src[src][0]:+.2f} pts)")

        deltas = sorted(((b_pc[c] - a_pc[c], c) for c in classes), reverse=True)
        print("\n  biggest per-class gains:")
        for d, c in deltas[:5]:
            print(f"    {c:16s} {a_pc[c]:6.2f}% -> {b_pc[c]:6.2f}%  ({d:+.1f})")
        print("\n  biggest per-class regressions:")
        for d, c in deltas[-5:]:
            print(f"    {c:16s} {a_pc[c]:6.2f}% -> {b_pc[c]:6.2f}%  ({d:+.1f})")

        weakest = sorted((b_pc[c], c) for c in classes)[:5]
        print(f"\n  weakest classes in {b_name}:")
        for acc, c in weakest:
            print(f"    {c:16s} {acc:6.2f}%")


if __name__ == "__main__":
    main()
