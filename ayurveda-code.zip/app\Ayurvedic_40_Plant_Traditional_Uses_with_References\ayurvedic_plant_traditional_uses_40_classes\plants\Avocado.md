# Avocado — Avocado

**Scientific name:** Persea americana
**Taxonomy confidence:** high
**Taxonomy note:** The class label corresponds to Persea americana.

## Traditional uses reported in the literature
- Menorrhagia/heavy menstrual bleeding in traditional reports
- Hypertension
- Stomach ache
- Bronchitis
- Diarrhea
- Diabetes

## Traditional treatment context
Traditional use varies by plant part and culture. The cited review documents these ethnomedicinal indications.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
These traditional uses do not establish effectiveness for hypertension, diabetes, bleeding or bronchitis; such conditions need appropriate medical care.

## References
1. Yasir M, Das S, Kharya MD. Pharmacognosy Reviews. 2010;4(7):77-84. *The phytochemical and pharmacological profile of Persea americana Mill*. DOI: https://doi.org/10.4103/0973-7847.65332 Online: https://pubmed.ncbi.nlm.nih.gov/22228945/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
