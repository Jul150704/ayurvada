# Nithyapushpa — Nithyapushpa / Madagascar periwinkle

**Scientific name:** Catharanthus roseus (probable)
**Taxonomy confidence:** probable
**Taxonomy note:** “Nithyapushpa/Nityapushpa” commonly denotes Catharanthus roseus in Indian vernacular usage.

## Traditional uses reported in the literature
- Traditional diabetes use
- Stomach disorders
- Kidney and liver complaints
- Cardiovascular complaints
- Traditional cancer-related use

## Traditional treatment context
Traditional claims are historically important because research on the plant led to isolation of vinca alkaloids used as prescription anticancer drugs.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
HIGH-RISK: The whole plant contains potent alkaloids. Vincristine/vinblastine are purified prescription medicines with significant toxicity; home-made periwinkle preparations are not cancer treatments and should not be ingested for self-medication.

## References
1. Kumar S, Singh B, Singh R. Journal of Ethnopharmacology. 2022;284:114647. *Catharanthus roseus (L.) G. Don: A review of its ethnobotany, phytochemistry, ethnopharmacology and toxicities*. DOI: https://doi.org/10.1016/j.jep.2021.114647 Online: https://pubmed.ncbi.nlm.nih.gov/34562562/
2. StatPearls/NCBI Bookshelf; PubMed indexed overview (PMID 32491774). *Vinca Alkaloid Toxicity*. Online: https://pubmed.ncbi.nlm.nih.gov/32491774/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
