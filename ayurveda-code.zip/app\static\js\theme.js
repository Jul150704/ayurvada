/* Runs synchronously in <head> so the theme is settled before first paint.
   Deliberately not a module — modules are deferred, which would flash. */
(function () {
  var root = document.documentElement;

  try {
    var stored = localStorage.getItem("ayurvana:theme");

    if (stored === "moonlight" || stored === "garden") {
      root.setAttribute("data-theme", stored);
      return;
    }
  } catch (e) {
    /* Private mode or blocked storage — fall through to the system preference. */
  }

  // No stored choice: drop the attribute so the prefers-color-scheme
  // block in tokens.css decides.
  root.removeAttribute("data-theme");
})();
