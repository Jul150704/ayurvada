/* ============================================================
   My Garden — saved plants, botanist levels, badges

   Badges track things that actually happened (plants saved,
   research opened, discoveries made). The catalogue has no family
   taxonomy, so there are deliberately no "plant family" badges
   rather than invented ones.
   ============================================================ */

import { revealChildren } from "./motion.js";
import { toast } from "./ui.js";

const PLANTS_KEY = "ayurvana:garden";
const STATS_KEY = "ayurvana:stats";

const LEVELS = [
  { name: "Seedling",  at: 0,  next: 3,  hint: "Save three plants to sprout" },
  { name: "Sprout",    at: 3,  next: 8,  hint: "Eight plants makes an herbalist" },
  { name: "Herbalist", at: 8,  next: 16, hint: "Sixteen plants and you are a vaidya" },
  { name: "Vaidya",    at: 16, next: 16, hint: "The whole garden knows you" },
];

const BADGES = [
  { id: "first",     label: "First leaf",   glyph: "#i-leaf",     test: (s) => s.saved >= 1 },
  { id: "grove",     label: "Grove",        glyph: "#i-sprout",   test: (s) => s.saved >= 5 },
  { id: "canopy",    label: "Canopy",       glyph: "#i-flower",   test: (s) => s.saved >= 12 },
  { id: "scholar",   label: "Scholar",      glyph: "#i-scroll",   test: (s) => s.researched >= 5 },
  { id: "wanderer",  label: "Wanderer",     glyph: "#i-compass",  test: (s) => s.discovered >= 5 },
  { id: "moonlit",   label: "Night walker", glyph: "#i-moon",     test: (s) => s.nightWalker },
];

/* ---- Storage ---------------------------------------------- */

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    /* Storage unavailable — the session still works, it just won't persist. */
  }
}

export function getPlants() {
  const list = read(PLANTS_KEY, []);
  return Array.isArray(list) ? list : [];
}

function getStats() {
  const s = read(STATS_KEY, {});
  return {
    researched: Array.isArray(s.researched) ? s.researched : [],
    discovered: Number(s.discovered) || 0,
    nightWalker: Boolean(s.nightWalker),
    earned: Array.isArray(s.earned) ? s.earned : [],
  };
}

function saveStats(stats) {
  write(STATS_KEY, stats);
}

export function has(label) {
  return getPlants().some((p) => p.class_label === label);
}

/* ---- Mutations --------------------------------------------- */

export function savePlant(plant) {
  const list = getPlants();
  if (list.some((p) => p.class_label === plant.class_label)) return false;

  list.push({
    class_label: plant.class_label,
    display_name: plant.display_name,
    sanskrit_name: plant.sanskrit_name || null,
    saved_at: new Date().toISOString(),
  });

  write(PLANTS_KEY, list);
  render();
  checkBadges();
  return true;
}

export function removePlant(label) {
  write(PLANTS_KEY, getPlants().filter((p) => p.class_label !== label));
  render();
}

export function noteResearchOpened(label) {
  const stats = getStats();
  if (stats.researched.includes(label)) return;

  stats.researched.push(label);
  saveStats(stats);
  checkBadges();
}

export function noteDiscovery() {
  const stats = getStats();
  stats.discovered += 1;
  saveStats(stats);
  checkBadges();
}

export function noteNightWalk() {
  const stats = getStats();
  if (stats.nightWalker) return;

  stats.nightWalker = true;
  saveStats(stats);
  checkBadges();
}

/* ---- Badges ------------------------------------------------ */

function currentState() {
  const stats = getStats();
  return {
    saved: getPlants().length,
    researched: stats.researched.length,
    discovered: stats.discovered,
    nightWalker: stats.nightWalker,
  };
}

function checkBadges() {
  const stats = getStats();
  const state = currentState();
  let changed = false;

  BADGES.forEach((badge) => {
    if (stats.earned.includes(badge.id)) return;
    if (!badge.test(state)) return;

    stats.earned.push(badge.id);
    changed = true;

    toast({
      title: `Badge earned · ${badge.label}`,
      text: encouragementFor(badge.id),
      icon: badge.glyph,
    });
  });

  if (changed) saveStats(stats);
  renderBadges();
}

function encouragementFor(id) {
  return {
    first: "Your garden has its first resident. It only grows from here.",
    grove: "Five plants in. You are starting to see the patterns.",
    canopy: "Twelve saved — that is nearly a third of the catalogue.",
    scholar: "You have read the sources behind five plants. That is the real work.",
    wanderer: "Five discoveries made by wandering rather than searching.",
    moonlit: "You found the garden after dark. The fireflies noticed.",
  }[id] || "Well wandered.";
}

/* ---- Render ------------------------------------------------ */

export function render() {
  const beds = document.getElementById("gardenBeds");
  const empty = document.getElementById("gardenEmpty");
  if (!beds || !empty) return;

  const plants = getPlants();

  beds.textContent = "";
  empty.classList.toggle("hidden", plants.length > 0);

  plants.forEach((plant) => beds.appendChild(sproutCard(plant)));

  if (plants.length) revealChildren(beds);

  renderLevel(plants.length);
  renderBadges();
}

function sproutCard(plant) {
  const el = document.createElement("article");
  el.className = "sprout";

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "sprout__glyph");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", "#i-sprout");
  svg.appendChild(use);

  const name = document.createElement("p");
  name.className = "sprout__name";
  name.textContent = plant.display_name;

  el.append(svg, name);

  if (plant.sanskrit_name && plant.sanskrit_name.devanagari) {
    const deva = document.createElement("p");
    deva.className = "sprout__deva deva";
    deva.textContent = plant.sanskrit_name.devanagari;
    el.appendChild(deva);
  }

  const remove = document.createElement("button");
  remove.className = "sprout__remove";
  remove.type = "button";
  remove.setAttribute("aria-label", `Remove ${plant.display_name} from my garden`);

  const rsvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  rsvg.setAttribute("aria-hidden", "true");
  const ruse = document.createElementNS("http://www.w3.org/2000/svg", "use");
  ruse.setAttribute("href", "#i-x");
  rsvg.appendChild(ruse);
  remove.appendChild(rsvg);

  remove.addEventListener("click", () => {
    removePlant(plant.class_label);
    document.dispatchEvent(
      new CustomEvent("garden:changed", { detail: { label: plant.class_label } })
    );
  });

  el.appendChild(remove);
  return el;
}

function renderLevel(count) {
  const nameEl = document.getElementById("levelName");
  const hintEl = document.getElementById("levelHint");
  const fill = document.getElementById("levelFill");
  const bar = document.getElementById("levelBar");
  if (!nameEl || !fill || !bar) return;

  let level = LEVELS[0];
  for (const candidate of LEVELS) {
    if (count >= candidate.at) level = candidate;
  }

  const span = level.next - level.at;
  const pct = span <= 0 ? 100 : Math.min(100, ((count - level.at) / span) * 100);

  nameEl.textContent = level.name;

  if (hintEl) {
    hintEl.textContent =
      count === 0
        ? "Save a plant to begin"
        : level.name === "Vaidya"
        ? `${count} plants tended`
        : level.hint;
  }

  fill.style.setProperty("width", `${pct}%`);
  bar.setAttribute("aria-valuenow", String(Math.round(pct)));
}

function renderBadges() {
  const wrap = document.getElementById("badges");
  if (!wrap) return;

  const earned = getStats().earned;
  wrap.textContent = "";

  BADGES.forEach((badge) => {
    const el = document.createElement("span");
    const got = earned.includes(badge.id);

    el.className = got ? "badge" : "badge badge--locked";
    el.title = got ? encouragementFor(badge.id) : "Not yet earned";

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "badge__glyph");
    svg.setAttribute("aria-hidden", "true");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", badge.glyph);
    svg.appendChild(use);

    const label = document.createElement("span");
    label.textContent = badge.label;

    el.append(svg, label);
    wrap.appendChild(el);
  });
}

export function initGarden() {
  render();
}
