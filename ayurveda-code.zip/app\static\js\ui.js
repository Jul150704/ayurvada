/* ============================================================
   Shared UI: toasts and the plant-part popover
   ============================================================ */

import { prefersReducedMotion } from "./motion.js";

/* ---- Toast ------------------------------------------------- */

export function toast({ title, text, icon = "#i-leaf", duration = 7000 }) {
  const region = document.getElementById("toasts");
  if (!region) return;

  const el = document.createElement("div");
  el.className = "toast";

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "toast__glyph");
  svg.setAttribute("aria-hidden", "true");

  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", icon);
  svg.appendChild(use);

  const body = document.createElement("div");
  body.className = "toast__body";

  if (title) {
    const t = document.createElement("strong");
    t.className = "toast__title";
    t.textContent = title;
    body.appendChild(t);
  }

  const p = document.createElement("span");
  p.className = "toast__text";
  p.textContent = text;
  body.appendChild(p);

  const close = document.createElement("button");
  close.className = "icon-btn btn--small";
  close.setAttribute("aria-label", "Dismiss");
  close.textContent = "×";

  el.append(svg, body, close);
  region.appendChild(el);

  if (!prefersReducedMotion()) {
    el.animate(
      [
        { opacity: 0, transform: "translateY(14px) scale(0.98)" },
        { opacity: 1, transform: "none" },
      ],
      { duration: 520, easing: "cubic-bezier(0.22,0.68,0.28,1)" }
    );
  }

  let timer = window.setTimeout(dismiss, duration);

  function dismiss() {
    window.clearTimeout(timer);
    if (!el.isConnected) return;

    if (prefersReducedMotion()) {
      el.remove();
      return;
    }

    const out = el.animate(
      [{ opacity: 1 }, { opacity: 0, transform: "translateY(10px)" }],
      { duration: 380, easing: "ease" }
    );
    out.onfinish = () => el.remove();
  }

  close.addEventListener("click", dismiss);
  el.addEventListener("mouseenter", () => window.clearTimeout(timer));
  el.addEventListener("mouseleave", () => {
    timer = window.setTimeout(dismiss, 2600);
  });

  return dismiss;
}

/* ---- Popover ----------------------------------------------- */

let activeTrigger = null;

export function initPopover() {
  const pop = document.getElementById("popover");
  if (!pop) return { open: () => {}, close: () => {} };

  const close = () => {
    pop.dataset.open = "false";
    pop.setAttribute("aria-hidden", "true");

    if (activeTrigger) {
      activeTrigger.setAttribute("aria-expanded", "false");
      activeTrigger = null;
    }
  };

  const open = (trigger, { title, text }) => {
    if (activeTrigger === trigger) {
      close();
      return;
    }

    pop.textContent = "";

    if (title) {
      const h = document.createElement("p");
      h.className = "popover__title";
      h.textContent = title;
      pop.appendChild(h);
    }

    const body = document.createElement("div");

    if (Array.isArray(text)) {
      const ul = document.createElement("ul");
      ul.className = "leaf-list";
      text.forEach((line) => {
        const li = document.createElement("li");
        li.textContent = line;
        ul.appendChild(li);
      });
      body.appendChild(ul);
    } else {
      body.textContent = text;
    }

    pop.appendChild(body);

    pop.dataset.open = "true";
    pop.setAttribute("aria-hidden", "false");

    activeTrigger = trigger;
    trigger.setAttribute("aria-expanded", "true");

    position(pop, trigger);
  };

  document.addEventListener("click", (e) => {
    if (!activeTrigger) return;
    if (pop.contains(e.target) || activeTrigger.contains(e.target)) return;
    close();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && activeTrigger) {
      const t = activeTrigger;
      close();
      t.focus();
    }
  });

  window.addEventListener(
    "scroll",
    () => {
      if (activeTrigger) position(pop, activeTrigger);
    },
    { passive: true }
  );

  return { open, close };
}

function position(pop, trigger) {
  const r = trigger.getBoundingClientRect();

  // Measure first, then clamp inside the viewport.
  pop.style.setProperty("left", "0px");
  pop.style.setProperty("top", "0px");

  const w = pop.offsetWidth;
  const h = pop.offsetHeight;
  const margin = 12;

  let left = r.left + window.scrollX + r.width / 2 - w / 2;
  left = Math.max(
    margin + window.scrollX,
    Math.min(left, window.scrollX + document.documentElement.clientWidth - w - margin)
  );

  // Prefer above; flip below when there isn't room.
  let top = r.top + window.scrollY - h - 10;
  if (r.top - h - 10 < 0) top = r.bottom + window.scrollY + 10;

  pop.style.setProperty("left", `${left}px`);
  pop.style.setProperty("top", `${top}px`);
}
