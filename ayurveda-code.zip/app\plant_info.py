from pathlib import Path
import json

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "plant_info" / "plant_information.json"
SANSKRIT_PATH = PROJECT_ROOT / "data" / "plant_info" / "sanskrit_names.json"


def load_plant_information():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Plant information file not found: {DATA_PATH}"
        )

    with open(DATA_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    return {
        plant["class_label"]: plant
        for plant in data["plants"]
    }


def load_sanskrit_names():
    if not SANSKRIT_PATH.exists():
        return {}

    with open(SANSKRIT_PATH, "r", encoding="utf-8") as f:
        return json.load(f).get("names", {})


PLANT_INFORMATION = load_plant_information()
SANSKRIT_NAMES = load_sanskrit_names()


def get_plant_information(class_label):
    plant = PLANT_INFORMATION.get(class_label)

    if plant is None:
        return None

    sanskrit = SANSKRIT_NAMES.get(class_label)

    if sanskrit:
        plant = {**plant, "sanskrit_name": sanskrit}

    return plant


# Themes are derived from the wording of the sourced use text itself — no
# category is asserted that the underlying literature did not describe.
USE_THEMES = {
    "Skin & wounds":     ("skin", "wound", "burn", "dermat", "eczema", "fungal", "acne", "scab"),
    "Digestion":         ("digest", "stomach", "gastro", "diarrh", "dysenter", "constipat",
                          "laxative", "ulcer", "pile", "hemorrhoid", "anthelmintic", "worm",
                          "appetite", "bowel"),
    "Respiratory":       ("cough", "cold", "asthma", "bronch", "throat", "congestion",
                          "catarrh", "respirat"),
    "Fever":             ("fever", "febrile", "malaria"),
    "Pain & inflammation": ("pain", "inflamm", "arthrit", "rheumat", "ache", "swell"),
    "Metabolic":         ("diabet", "glucose", "glycem", "cholesterol"),
    "Women's health":    ("menstrua", "menorrh", "gynaecolog", "gynecolog", "reproductive",
                          "pregnan", "uterine", "lactat"),
    "Mind & sleep":      ("memory", "insomnia", "sleep", "anxiet", "cognitiv", "learning",
                          "nervous", "stress", "headache"),
    "Vitality":          ("rasayana", "rejuven", "strength", "nourish", "tonic", "vitality"),
}


def _themes_for(plant):
    haystack = " ".join([
        " ".join(plant.get("traditional_uses_reported") or []),
        plant.get("traditional_treatment_context") or "",
    ]).lower()

    return sorted(
        theme
        for theme, keywords in USE_THEMES.items()
        if any(keyword in haystack for keyword in keywords)
    )


def get_catalogue():
    """Lightweight index of every plant, for the library, search and discovery."""
    entries = []

    for label, plant in PLANT_INFORMATION.items():
        uses = plant.get("traditional_uses_reported") or []

        entries.append({
            "class_label": label,
            "display_name": plant.get("display_name", label),
            "scientific_name": plant.get("scientific_name", ""),
            "sanskrit_name": SANSKRIT_NAMES.get(label),
            "summary": uses[0] if uses else "",
            "uses": uses,
            "themes": _themes_for(plant),
            "use_count": len(uses),
            "reference_count": len(plant.get("references") or []),
        })

    entries.sort(key=lambda e: e["display_name"].lower())
    return entries


def get_statistics():
    """Real, non-fabricated counts for the trust strip."""
    references = [
        reference
        for plant in PLANT_INFORMATION.values()
        for reference in (plant.get("references") or [])
    ]

    return {
        "plants": len(PLANT_INFORMATION),
        "references": len(references),
        "unique_dois": len({r.get("doi") for r in references if r.get("doi")}),
    }
