/* ============================================================
   AyurVana — entry point
   Wires the upload flow together with the library, the journal
   and the garden.
   ============================================================ */

import {
  initReveal,
  initParallax,
  initFireflies,
  initTheme,
  isMoonlight,
  prefersReducedMotion,
} from "./motion.js";

import { toast } from "./ui.js";
import { initSound } from "./audio.js";
import * as Garden from "./garden.js";
import { initLibrary } from "./library.js";
import { initJournal, renderJournal } from "./journal.js";

const LOADING_LINES = [
  "Consulting the ancient texts…",
  "Reading the venation…",
  "Comparing leaf margins…",
  "Turning pages in the herbarium…",
  "Matching against forty specimens…",
  "Asking the garden…",
];

const form = document.getElementById("uploadForm");
const input = document.getElementById("imageInput");
const dropZone = document.getElementById("dropZone");
const preview = document.getElementById("previewImage");
const clearBtn = document.getElementById("clearBtn");
const identifyBtn = document.getElementById("identifyBtn");
const loading = document.getElementById("loading");
const loadingText = document.getElementById("loadingText");
const errorBox = document.getElementById("uploadError");

let previewDataUrl = null;
let loadingTimer = null;

/* ------------------------------------------------------------
   Image preview

   The page's CSP allows img-src 'self' data: but not blob:, so the
   preview is read as a data URL. An object URL would silently fail
   to render under that policy.
   ------------------------------------------------------------ */

function showPreview(file) {
  if (!file) return;

  if (!file.type.startsWith("image/")) {
    showError("That file is not an image. Please choose a JPG, PNG or WebP.");
    return;
  }

  const reader = new FileReader();

  reader.onload = () => {
    previewDataUrl = reader.result;
    preview.src = previewDataUrl;
    preview.classList.remove("hidden");
    clearBtn.classList.remove("hidden");
    clearError();
  };

  reader.onerror = () => showError("That image could not be read. Please try another file.");

  reader.readAsDataURL(file);
}

function clearSelection() {
  input.value = "";
  previewDataUrl = null;

  preview.classList.add("hidden");
  preview.removeAttribute("src");
  clearBtn.classList.add("hidden");
  clearError();
}

input.addEventListener("change", () => {
  const file = input.files[0];
  if (file) showPreview(file);
  else clearSelection();
});

clearBtn.addEventListener("click", clearSelection);

/* ---- Drag and drop ----------------------------------------- */

["dragenter", "dragover"].forEach((type) => {
  dropZone.addEventListener(type, (e) => {
    e.preventDefault();
    dropZone.classList.add("is-dragging");
  });
});

["dragleave", "drop"].forEach((type) => {
  dropZone.addEventListener(type, (e) => {
    e.preventDefault();
    if (type === "dragleave" && dropZone.contains(e.relatedTarget)) return;
    dropZone.classList.remove("is-dragging");
  });
});

dropZone.addEventListener("drop", (e) => {
  const file = e.dataTransfer && e.dataTransfer.files[0];
  if (!file) return;

  // Put the dropped file into the input so the form submits it normally.
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;

  showPreview(file);
});

/* ---- Errors ------------------------------------------------ */

function showError(message) {
  errorBox.textContent = "";

  const box = document.createElement("div");
  box.className = "caution";

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", "#i-alert");
  svg.appendChild(use);

  const p = document.createElement("p");
  p.textContent = message;

  box.append(svg, p);
  errorBox.appendChild(box);
  errorBox.classList.remove("hidden");
}

function clearError() {
  errorBox.classList.add("hidden");
  errorBox.textContent = "";
}

/* ---- Poetic loading ---------------------------------------- */

function startLoading() {
  let i = 0;

  loadingText.textContent = LOADING_LINES[0];
  loading.classList.remove("hidden");
  identifyBtn.disabled = true;

  loadingTimer = window.setInterval(() => {
    i = (i + 1) % LOADING_LINES.length;

    if (prefersReducedMotion()) {
      loadingText.textContent = LOADING_LINES[i];
      return;
    }

    loadingText.style.setProperty("opacity", "0");

    window.setTimeout(() => {
      loadingText.textContent = LOADING_LINES[i];
      loadingText.style.setProperty("opacity", "1");
    }, 240);
  }, 2600);
}

function stopLoading() {
  window.clearInterval(loadingTimer);
  loading.classList.add("hidden");
  identifyBtn.disabled = false;
  loadingText.style.removeProperty("opacity");
}

/* ---- Submit ------------------------------------------------ */

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const file = input.files[0];

  if (!file) {
    toast({ text: "Choose a photograph of a leaf first.", icon: "#i-leaf" });
    return;
  }

  clearError();
  startLoading();

  const body = new FormData();
  body.append("file", file);

  try {
    const response = await fetch("/predict", { method: "POST", body });
    const data = await response.json();

    if (!response.ok) {
      showError(data.error || "The garden could not read that image.");
      return;
    }

    if (data.status === "model_not_trained") {
      showError(
        "The trained model is not available on this server, so no identification can be made."
      );
      return;
    }

    renderJournal(data, {
      confidence: typeof data.confidence === "number" ? data.confidence : undefined,
      image: previewDataUrl,
    });
  } catch (error) {
    console.error(error);
    showError("The garden could not be reached. Please check your connection and try again.");
  } finally {
    stopLoading();
  }
});

/* ---- Opening a plant from the library ---------------------- */

async function openPlant(label) {
  try {
    const response = await fetch(`/api/plants/${encodeURIComponent(label)}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const plant = await response.json();
    renderJournal(plant, {});
  } catch (error) {
    console.error(error);
    toast({ text: "That entry could not be opened.", icon: "#i-alert" });
  }
}

/* ---- FAQ --------------------------------------------------- */

function initFaq() {
  const fab = document.getElementById("chatFab");
  const panel = document.getElementById("chat");
  const close = document.getElementById("chatClose");
  const log = document.getElementById("chatLog");
  if (!fab || !panel) return;

  const setOpen = (open) => {
    panel.classList.toggle("hidden", !open);
    fab.setAttribute("aria-expanded", String(open));
    if (open) panel.querySelector(".chat__q")?.focus();
  };

  fab.addEventListener("click", () => setOpen(panel.classList.contains("hidden")));
  close.addEventListener("click", () => {
    setOpen(false);
    fab.focus();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !panel.classList.contains("hidden")) {
      setOpen(false);
      fab.focus();
    }
  });

  document.querySelectorAll(".chat__q").forEach((btn) => {
    btn.addEventListener("click", () => {
      const answer = document.createElement("p");
      answer.className = "bubble";
      answer.textContent = btn.dataset.answer;

      log.appendChild(answer);
      log.scrollTop = log.scrollHeight;
    });
  });
}

/* ---- Boot -------------------------------------------------- */

function boot() {
  initReveal();
  initParallax();
  initJournal();
  initSound();
  initFaq();
  Garden.initGarden();

  const renderFireflies = initFireflies();

  initTheme((moon) => {
    if (renderFireflies) renderFireflies();
    if (moon) Garden.noteNightWalk();
  });

  initLibrary(openPlant);

  // Deep link: /#plant=Neem
  const match = location.hash.match(/plant=([^&]+)/);
  if (match) openPlant(decodeURIComponent(match[1]));

  window.addEventListener("hashchange", () => {
    const next = location.hash.match(/plant=([^&]+)/);
    if (next) openPlant(decodeURIComponent(next[1]));
  });

  document.addEventListener("garden:changed", () => Garden.render());
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", boot);
} else {
  boot();
}
