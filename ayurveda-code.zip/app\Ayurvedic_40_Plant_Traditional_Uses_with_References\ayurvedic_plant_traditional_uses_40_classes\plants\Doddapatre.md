# Doddapatre — Doddapatre / Indian borage

**Scientific name:** Plectranthus amboinicus (syn. Coleus amboinicus)
**Taxonomy confidence:** high
**Taxonomy note:** Doddapatre commonly refers to Plectranthus/Coleus amboinicus in Karnataka and South India.

## Traditional uses reported in the literature
- Cough, sore throat and nasal congestion
- Asthma and bronchitis-related traditional use
- Digestive complaints and constipation
- Topical use for burns, bruises, inflammation and insect bites

## Traditional treatment context
Leaves and aromatic preparations are commonly described ethnomedicinally; no dose is provided.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Respiratory symptoms can require urgent medical care. Essential oils/concentrated extracts can have different risks from culinary leaf use.

## References
1. Filipe MS, et al. Pharmaceuticals. 2025;18(5):707. *Plectranthus amboinicus: A Systematic Review of Traditional Uses, Phytochemical Properties, and Therapeutic Applications*. DOI: https://doi.org/10.3390/ph18050707 Online: https://pubmed.ncbi.nlm.nih.gov/40430526/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
