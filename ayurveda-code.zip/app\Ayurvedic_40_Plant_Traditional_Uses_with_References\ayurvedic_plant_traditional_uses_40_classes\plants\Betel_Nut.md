# Betel_Nut — Betel nut / Areca nut

**Scientific name:** Areca catechu
**Taxonomy confidence:** high
**Taxonomy note:** Betel nut/areca nut is the seed of Areca catechu.

## Traditional uses reported in the literature
- Traditional anthelmintic use
- Digestive/stimulant use
- Traditional use for abdominal fluid accumulation and related complaints

## Traditional treatment context
Historical medicinal use is documented, but this is included for ethnobotanical completeness—not as a recommendation.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
HIGH-RISK: Areca nut chewing is carcinogenic to humans and is associated with oral submucous fibrosis and oral cancer risk. It should not be presented or recommended as a treatment.

## References
1. Review indexed in Journal of Ethnopharmacology (PMID 25681543). *Areca catechu L. (Arecaceae): a review of its traditional uses, botany, phytochemistry, pharmacology and toxicology*. DOI: https://doi.org/10.1016/j.jep.2015.02.010 Online: https://pubmed.ncbi.nlm.nih.gov/25681543/
2. International Agency for Research on Cancer (IARC), Monographs Volume 85. *IARC Monographs: Betel-quid and Areca-nut Chewing and Some Areca-nut-derived Nitrosamines*. Online: https://www.ncbi.nlm.nih.gov/books/NBK316567/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
