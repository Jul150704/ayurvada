# Ashoka — Ashoka

**Scientific name:** Saraca asoca
**Taxonomy confidence:** high
**Taxonomy note:** Ashoka is the standard medicinal common name for Saraca asoca in Ayurveda.

## Traditional uses reported in the literature
- Gynecological complaints
- Menstrual and uterine complaints
- Traditional women’s health formulations

## Traditional treatment context
Bark and formulations containing Saraca asoca are prominent in traditional Indian medicine; no dosing instructions are included.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Gynecological symptoms such as heavy bleeding can indicate serious conditions and require clinical evaluation. Evidence and product identity can vary.

## References
1. Urumarudappa SKJ, et al. Journal of Ethnopharmacology. 2023;317:116861. *A comprehensive review on Saraca asoca (Fabaceae) - Historical perspective, traditional uses, biological activities, and conservation*. DOI: https://doi.org/10.1016/j.jep.2023.116861 Online: https://pubmed.ncbi.nlm.nih.gov/37390875/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
