# Basale — Basale / Malabar spinach

**Scientific name:** Basella alba
**Taxonomy confidence:** high
**Taxonomy note:** Basale commonly refers to Basella alba in South India.

## Traditional uses reported in the literature
- Traditional demulcent/emollient use
- Digestive and bowel-support/laxative use
- Diuretic/urinary traditional use
- Wound and inflammation-related traditional use

## Traditional treatment context
Leaves and other parts are used as food and in traditional remedies. No therapeutic dose is supplied.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Food use does not automatically establish medicinal efficacy; concentrated extracts can differ from dietary use.

## References
1. Bose A, Banerjee S, Mandal SK, Bose S, Maity S. Journal of Natural Remedies. 2023;23(4):1307-1326. *Comprehensive Ethnomedicinal, Pharmacological and Phytochemical Report on Basella alba L. (Basellaceae)*. DOI: https://doi.org/10.18311/jnr/2023/34287 Online: https://doi.org/10.18311/jnr/2023/34287

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
