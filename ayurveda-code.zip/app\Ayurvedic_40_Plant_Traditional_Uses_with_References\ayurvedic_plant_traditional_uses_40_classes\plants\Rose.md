# Rose — Rose

**Scientific name:** Rosa spp. (representative source: Rosa damascena)
**Taxonomy confidence:** ambiguous
**Taxonomy note:** The class label does not identify a rose species. The cited medicinal review is for Rosa damascena and is representative only.

## Traditional uses reported in the literature
- Chest and abdominal pain in R. damascena traditional use
- Constipation and digestive disorders
- Menstrual bleeding complaints
- Liver ailments
- Aromatic calming/comfort uses in traditional practice

## Traditional treatment context
Rose species, hips, petals and oils are chemically different; display a taxonomy warning in the app.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Do not generalize medicinal claims from R. damascena to every Rosa species. Essential oils can irritate or cause allergy.

## References
1. Akram M, et al. Journal of Pharmacy and Pharmacology. 2020;72(2):161-174. *Chemical constituents, experimental and clinical pharmacology of Rosa damascena: a literature review*. DOI: https://doi.org/10.1111/jphp.13185 Online: https://pubmed.ncbi.nlm.nih.gov/31709541/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
