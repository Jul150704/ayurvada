# Pepper — Black pepper

**Scientific name:** Piper nigrum
**Taxonomy confidence:** high
**Taxonomy note:** The medicinal dataset label “Pepper” is most consistent with black pepper, Piper nigrum.

## Traditional uses reported in the literature
- Menstrual complaints in Indian folk reports
- Ear-nose-throat complaints
- Digestive/gastrointestinal traditional use
- Cold/cough-related spice-medicine use

## Traditional treatment context
Fruits/seeds are commonly used as spice and in traditional formulas; concentrated piperine is pharmacologically different from culinary quantities.

## Evidence note
Traditional/ethnomedicinal use is documented in the cited review. This is not equivalent to proven clinical efficacy; many reported pharmacological effects are preclinical or require stronger human trials.

## Safety note
Piperine can alter drug absorption/metabolism. Do not use concentrated extracts to replace prescribed therapy.

## References
1. Takooree H, et al. Critical Reviews in Food Science and Nutrition. 2019;59(sup1):S210-S243. *A systematic review on black pepper (Piper nigrum L.): from folk uses to pharmacological applications*. DOI: https://doi.org/10.1080/10408398.2019.1565489 Online: https://pubmed.ncbi.nlm.nih.gov/30740986/

---
Educational/research content only. The entries describe traditional or ethnomedicinal uses reported in the cited literature; they do not establish that a plant is safe or clinically effective for treating a disease. Do not use an AI plant identification or this dataset to diagnose, prescribe, dose, ingest, or replace professional medical/Ayurvedic care. Plant identity, plant part, preparation, dose, interactions, pregnancy status, and contamination can materially change risk.
