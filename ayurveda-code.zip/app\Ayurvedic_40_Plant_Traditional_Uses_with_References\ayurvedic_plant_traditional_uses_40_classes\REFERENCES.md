# Reference papers and authoritative safety sources



The package uses peer-reviewed review papers wherever possible. One authoritative IARC monograph is included for areca-nut carcinogenicity. Links point to PubMed/PMC, DOI records, or the publisher.



1. International Agency for Research on Cancer (IARC), Monographs Volume 85. **IARC Monographs: Betel-quid and Areca-nut Chewing and Some Areca-nut-derived Nitrosamines** (2004). Online: https://www.ncbi.nlm.nih.gov/books/NBK316567/

2. Prakash P, Gupta N. Indian Journal of Physiology and Pharmacology. 2005;49(2):125-131. **Therapeutic uses of Ocimum sanctum Linn (Tulsi) with a note on eugenol and its pharmacological actions: a short review** (2005). Online: https://pubmed.ncbi.nlm.nih.gov/16170979/

3. Surjushe A, Vasani R, Saple DG. Indian Journal of Dermatology. 2008;53(4):163-166. **Aloe vera: a short review** (2008). DOI: https://doi.org/10.4103/0019-5154.44785 Online: https://pmc.ncbi.nlm.nih.gov/articles/PMC2763764/

4. Pérez Gutiérrez RM, Mitchell S, Vargas Solis R. Journal of Ethnopharmacology. 2008;117(1):1-27. **Psidium guajava: a review of its traditional uses, phytochemistry and pharmacology** (2008). DOI: https://doi.org/10.1016/j.jep.2008.01.025 Online: https://pubmed.ncbi.nlm.nih.gov/18353572/

5. Yasir M, Das S, Kharya MD. Pharmacognosy Reviews. 2010;4(7):77-84. **The phytochemical and pharmacological profile of Persea americana Mill** (2010). DOI: https://doi.org/10.4103/0973-7847.65332 Online: https://pubmed.ncbi.nlm.nih.gov/22228945/

6. Worbs S, et al. Toxins. Review indexed in PubMed (PMID 22069699). **Ricinus communis intoxications in human and veterinary medicine—a summary of real cases** (2011). Online: https://pubmed.ncbi.nlm.nih.gov/22069699/

7. Pharmacognosy Reviews. Review indexed in PubMed (PMID 22171285). **Scientific basis for the therapeutic use of Cymbopogon citratus, stapf (Lemon grass)** (2011). DOI: https://doi.org/10.4103/2231-4040.79796 Online: https://pubmed.ncbi.nlm.nih.gov/22171285/

8. Singh D, Singh B, Goel RK. Journal of Ethnopharmacology. 2011;134(3):565-583. **Traditional uses, phytochemistry and pharmacology of Ficus religiosa: a review** (2011). DOI: https://doi.org/10.1016/j.jep.2011.01.046 Online: https://pubmed.ncbi.nlm.nih.gov/21296646/

9. Al Muqarrabun LMR, et al. Journal of Ethnopharmacology. 2013;150(2):395-420. **Medicinal uses, phytochemistry and pharmacology of Pongamia pinnata (L.) Pierre: a review** (2013). DOI: https://doi.org/10.1016/j.jep.2013.08.041 Online: https://pubmed.ncbi.nlm.nih.gov/24016802/

10. Kumar VS, Navaratnam V. Asian Pacific Journal of Tropical Biomedicine. 2013;3(7):505-514. **Neem (Azadirachta indica): prehistory to contemporary medicinal uses to humankind** (2013). DOI: https://doi.org/10.1016/S2221-1691(13)60105-7 Online: https://pubmed.ncbi.nlm.nih.gov/23835719/

11. Hegde PK, Rao HA, Rao PN. Pharmacognosy Reviews. 2014;8(15):67-72. **A review on Insulin plant (Costus igneus Nak)** (2014). DOI: https://doi.org/10.4103/0973-7847.125536 Online: https://pubmed.ncbi.nlm.nih.gov/24600198/

12. Semwal RB, et al. Journal of Ethnopharmacology. 2014;155(1):80-103. **Lawsonia inermis L. (henna): ethnobotanical, phytochemical and pharmacological aspects** (2014). DOI: https://doi.org/10.1016/j.jep.2014.05.042 Online: https://pubmed.ncbi.nlm.nih.gov/24886774/

13. de Boer HJ, et al. Journal of Ethnopharmacology. 2014. **Medicinal plants for women’s healthcare in southeast Asia: a meta-analysis of their traditional use, chemical constituents, and pharmacology** (2014). DOI: https://doi.org/10.1016/j.jep.2013.11.030 Online: https://pubmed.ncbi.nlm.nih.gov/24269772/

14. Review indexed in Journal of Ethnopharmacology (PMID 25681543). **Areca catechu L. (Arecaceae): a review of its traditional uses, botany, phytochemistry, pharmacology and toxicology** (2015). DOI: https://doi.org/10.1016/j.jep.2015.02.010 Online: https://pubmed.ncbi.nlm.nih.gov/25681543/

15. Ediriweera MK, Tennekoon KH, Samarakoon SR. Evidence-Based Complementary and Alternative Medicine. 2017:6949835. **A Review on Ethnopharmacological Applications, Pharmacological Activities, and Bioactive Compounds of Mangifera indica (Mango)** (2017). DOI: https://doi.org/10.1155/2017/6949835 Online: https://pubmed.ncbi.nlm.nih.gov/29456572/

16. Takooree H, et al. Critical Reviews in Food Science and Nutrition. 2019;59(sup1):S210-S243. **A systematic review on black pepper (Piper nigrum L.): from folk uses to pharmacological applications** (2019). DOI: https://doi.org/10.1080/10408398.2019.1565489 Online: https://pubmed.ncbi.nlm.nih.gov/30740986/

17. Franke H, Scholl R, Aigner A. Naunyn-Schmiedeberg’s Archives of Pharmacology. 2019. **Ricin and Ricinus communis in pharmacology and toxicology—from ancient use to modern perspectives** (2019). Online: https://pubmed.ncbi.nlm.nih.gov/31359089/

18. Akram M, et al. Journal of Pharmacy and Pharmacology. 2020;72(2):161-174. **Chemical constituents, experimental and clinical pharmacology of Rosa damascena: a literature review** (2020). DOI: https://doi.org/10.1111/jphp.13185 Online: https://pubmed.ncbi.nlm.nih.gov/31709541/

19. Klimek-Szczykutowicz M, Szopa A, Ekiert H. Plants. 2020;9(1):119. **Citrus limon (Lemon) Phenomenon—A Review of the Chemistry, Pharmacological Properties, Applications in the Modern Pharmaceutical, Food, and Cosmetics Industries, and Biotechnological Studies** (2020). DOI: https://doi.org/10.3390/plants9010119 Online: https://pubmed.ncbi.nlm.nih.gov/31963590/

20. Ge S, et al. Journal of Ethnopharmacology. 2021;271:113877. **A unique understanding of traditional medicine of pomegranate, Punica granatum L. and its current research status** (2021). DOI: https://doi.org/10.1016/j.jep.2021.113877 Online: https://pubmed.ncbi.nlm.nih.gov/33515685/

21. Review indexed in PubMed (PMID 33164294). **Is it safe to consume traditional medicinal plants during pregnancy?** (2021). Online: https://pubmed.ncbi.nlm.nih.gov/33164294/

22. Mahendran G, Verma SK, Rahman L-U. Journal of Ethnopharmacology. 2021;278:114266. **The traditional uses, phytochemistry and pharmacology of spearmint (Mentha spicata L.): A review** (2021). DOI: https://doi.org/10.1016/j.jep.2021.114266 Online: https://pubmed.ncbi.nlm.nih.gov/34087400/

23. Dahat Y, et al. Journal of Ethnopharmacology. 2021;276:114127. **Traditional uses, phytochemistry and pharmacological attributes of Pterocarpus santalinus and future directions: A review** (2021). DOI: https://doi.org/10.1016/j.jep.2021.114127 Online: https://pubmed.ncbi.nlm.nih.gov/33915135/

24. Mukherjee PK, et al. Journal of Ethnopharmacology. 2021;264:113157. **Withania somnifera (L.) Dunal - Modern perspectives of an ancient Rasayana from Ayurveda** (2021). DOI: https://doi.org/10.1016/j.jep.2020.113157 Online: https://pubmed.ncbi.nlm.nih.gov/32783987/

25. Sarfraz I, et al. Combinatorial Chemistry & High Throughput Screening. 2022;25(7):1181-1186. **A Review on Phyto-pharmacology of Oxalis corniculata** (2022). DOI: https://doi.org/10.2174/1386207324666210813121431 Online: https://pubmed.ncbi.nlm.nih.gov/34391377/

26. Biswas P, et al. Journal of Cellular and Molecular Medicine. 2022;26:3083-3119. **Betelvine (Piper betle L.): A comprehensive insight into its ethnopharmacology, phytochemistry, and pharmacological, biomedical and therapeutic attributes** (2022). DOI: https://doi.org/10.1111/jcmm.17323 Online: https://pmc.ncbi.nlm.nih.gov/articles/PMC9170825/

27. Kumar S, Singh B, Singh R. Journal of Ethnopharmacology. 2022;284:114647. **Catharanthus roseus (L.) G. Don: A review of its ethnobotany, phytochemistry, ethnopharmacology and toxicities** (2022). DOI: https://doi.org/10.1016/j.jep.2021.114647 Online: https://pubmed.ncbi.nlm.nih.gov/34562562/

28. Fatima U, et al. Frontiers in Nutrition. 2022;9:972379. **Pharmacological attributes of Bacopa monnieri extract: Current updates and clinical manifestation** (2022). DOI: https://doi.org/10.3389/fnut.2022.972379 Online: https://pubmed.ncbi.nlm.nih.gov/36061899/

29. Chen X, et al. Frontiers in Pharmacology. 2022;13:918071. **Solanum nigrum Linn.: An Insight into Current Research on Traditional Uses, Phytochemistry, and Pharmacology** (2022). DOI: https://doi.org/10.3389/fphar.2022.918071 Online: https://pubmed.ncbi.nlm.nih.gov/36052142/

30. Saini R, et al. Journal of Ethnopharmacology. 2022;282:114570. **Traditional uses, bioactive composition, pharmacology, and toxicology of Phyllanthus emblica fruits: A comprehensive review** (2022). DOI: https://doi.org/10.1016/j.jep.2021.114570 Online: https://pubmed.ncbi.nlm.nih.gov/34480995/

31. Urumarudappa SKJ, et al. Journal of Ethnopharmacology. 2023;317:116861. **A comprehensive review on Saraca asoca (Fabaceae) - Historical perspective, traditional uses, biological activities, and conservation** (2023). DOI: https://doi.org/10.1016/j.jep.2023.116861 Online: https://pubmed.ncbi.nlm.nih.gov/37390875/

32. Cheng Y, et al. Journal of Ethnopharmacology. 2023;306:116166. **Bamboo leaf: A review of traditional medicinal property, phytochemistry, pharmacology, and purification technology** (2023). DOI: https://doi.org/10.1016/j.jep.2023.116166 Online: https://pubmed.ncbi.nlm.nih.gov/36649850/

33. Bose A, Banerjee S, Mandal SK, Bose S, Maity S. Journal of Natural Remedies. 2023;23(4):1307-1326. **Comprehensive Ethnomedicinal, Pharmacological and Phytochemical Report on Basella alba L. (Basellaceae)** (2023). DOI: https://doi.org/10.18311/jnr/2023/34287 Online: https://doi.org/10.18311/jnr/2023/34287

34. Rivas-Gastelum MF, et al. Frontiers in Nutrition. 2023;10:1194283. **Manilkara zapota “chicozapote” as a fruit source of health-beneficial bioactive compounds and its effects on chronic degenerative and infectious diseases, a review** (2023). DOI: https://doi.org/10.3389/fnut.2023.1194283 Online: https://pubmed.ncbi.nlm.nih.gov/37469550/

35. Amtaghri S, et al. Endocrine, Metabolic & Immune Disorders - Drug Targets. 2024;24(1):86-115. **A Comprehensive Overview of Hibiscus rosa-sinensis L.: Its Ethnobotanical Uses, Phytochemistry, Therapeutic Uses, Pharmacological Activities, and Toxicology** (2024). DOI: https://doi.org/10.2174/1871530323666230522113405 Online: https://pubmed.ncbi.nlm.nih.gov/37218183/

36. Review indexed in PubMed (PMID 39473808). **A Comprehensive Review of the Phytochemical Constituents and Bioactivities of Ocimum tenuiflorum** (2024). Online: https://pubmed.ncbi.nlm.nih.gov/39473808/

37. Pharmacological Research - Natural Products. 2024:100062. **A systematic review on traditional use, phytochemistry and pharmacological activities of Manilkara zapota** (2024). DOI: https://doi.org/10.1016/j.prenap.2024.100062 Online: https://doi.org/10.1016/j.prenap.2024.100062

38. Journal of Ethnopharmacology. 2024; review indexed in PubMed (PMID 38608798). **Ethnobotanical uses, phytochemistry and bioactivities of Cymbopogon plants: A review** (2024). DOI: https://doi.org/10.1016/j.jep.2024.118181 Online: https://pubmed.ncbi.nlm.nih.gov/38608798/

39. Chaudhary A, et al. Heliyon. 2024;10(10):e31229. **Indian herb Tinospora cordifolia and Tinospora species: Phytochemical and therapeutic application** (2024). DOI: https://doi.org/10.1016/j.heliyon.2024.e31229 Online: https://pubmed.ncbi.nlm.nih.gov/38813196/

40. Jachak SM, et al. Current Pharmaceutical Design. 2024;30(41):3255-3275. **Murraya koenigii (L.) Spreng. as a Natural Intervention for Diabesity: A Review** (2024). DOI: https://doi.org/10.2174/0113816128304471240801183021 Online: https://pubmed.ncbi.nlm.nih.gov/39253925/

41. Alshehri B. Saudi Journal of Biological Sciences. 2024;31(4):103940. **The geranium genus: A comprehensive study on ethnomedicinal uses, phytochemical compounds, and pharmacological importance** (2024). DOI: https://doi.org/10.1016/j.sjbs.2024.103940 Online: https://pubmed.ncbi.nlm.nih.gov/38371877/

42. Luo et al. Drug Design, Development and Therapy. 2024. **Traditional Uses, Phytochemistry, Pharmacology and Toxicology of Ruta graveolens L.: A Critical Review and Future Perspectives** (2024). DOI: https://doi.org/10.2147/DDDT.S494417 Online: https://pubmed.ncbi.nlm.nih.gov/39758226/

43. StatPearls/NCBI Bookshelf; PubMed indexed overview (PMID 32491774). **Vinca Alkaloid Toxicity** (2024). Online: https://pubmed.ncbi.nlm.nih.gov/32491774/

44. Nascimento Júnior JAC, et al. Molecules. 2025;30(18):3831. **Botany, Ethnomedicinal Uses, Biological Activities, Phytochemistry, and Technological Applications of Morinda citrifolia Plants** (2025). DOI: https://doi.org/10.3390/molecules30183831 Online: https://pubmed.ncbi.nlm.nih.gov/41011723/

45. Akanda MKM, et al. Inflammopharmacology. 2025;33(6):3051-3084. **Carica papaya in health and disease: a review of its bioactive compounds for treating various disease conditions, including anti-inflammatory and anti-arthritic activities** (2025). DOI: https://doi.org/10.1007/s10787-025-01780-4 Online: https://pubmed.ncbi.nlm.nih.gov/40392387/

46. Filipe MS, et al. Pharmaceuticals. 2025;18(5):707. **Plectranthus amboinicus: A Systematic Review of Traditional Uses, Phytochemical Properties, and Therapeutic Applications** (2025). DOI: https://doi.org/10.3390/ph18050707 Online: https://pubmed.ncbi.nlm.nih.gov/40430526/

47. Review indexed in PubMed (PMID 42566010). **From traditional uses to biochemical evidence: phytochemical diversity and bioactivities of Calotropis gigantea—a comprehensive update since 2013** (2026). DOI: https://doi.org/10.1007/s00044-026-03602-w Online: https://pubmed.ncbi.nlm.nih.gov/42566010/

48. Wang H, et al. Journal of Ethnopharmacology. 2026;354:120478. **Jasminum sambac: Progress in research on ethnopharmacology, phytochemistry, pharmacological actions and other applications** (2026). DOI: https://doi.org/10.1016/j.jep.2025.120478 Online: https://pubmed.ncbi.nlm.nih.gov/40882791/